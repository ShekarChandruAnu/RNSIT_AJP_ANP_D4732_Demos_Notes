package com.anu.sprbootdemo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller

public class MyController {

	@GetMapping("/sayHi")
	public String sayHello()
	{
		return "welcome";
	}
	
	@GetMapping("/seeData")
	public ModelAndView showData()
	{
		ModelAndView mav = new ModelAndView();
		String message="Welcome to SPringBOOT Based MVC Projects";
		mav.setViewName("datapage");
		mav.addObject("message", message);
		return mav;
	}
}
