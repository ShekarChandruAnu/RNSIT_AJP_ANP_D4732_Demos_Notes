package com.anu.sprbootdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.anu.*")
public class SprbootdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprbootdemoApplication.class, args);
	}

}
