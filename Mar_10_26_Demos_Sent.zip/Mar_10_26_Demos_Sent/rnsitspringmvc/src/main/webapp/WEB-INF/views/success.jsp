<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="aqua">
<center>
<h2>Successful Login!!! Welcome to Employees Data Section...</h2>
<h2>Welcome : ${login.loginId}</h2>
<a href="employees/getData">Click Here to View Employees Details</a>
</center>
</body>
</html>