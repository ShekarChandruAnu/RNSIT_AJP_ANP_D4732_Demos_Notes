<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1" isELIgnored="false"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="yellow">
<h1>Welcome to OnlineShopping Site</h1>
<h2>${mymessage}</h2>
<a href="login/showLoginPage">Go To Login Page!!!</a>
</body>
</html>