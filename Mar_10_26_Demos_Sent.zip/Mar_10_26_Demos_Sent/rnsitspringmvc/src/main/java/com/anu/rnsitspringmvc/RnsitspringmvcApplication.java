package com.anu.rnsitspringmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.*")
public class RnsitspringmvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(RnsitspringmvcApplication.class, args);
		System.out.println("Welcome to SPRINGBoot based MVC Apps...");
	}

}
