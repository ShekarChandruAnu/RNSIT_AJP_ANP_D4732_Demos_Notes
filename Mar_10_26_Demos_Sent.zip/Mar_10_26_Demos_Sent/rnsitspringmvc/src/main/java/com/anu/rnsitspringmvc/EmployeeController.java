package com.anu.rnsitspringmvc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.anu.model.Employee;
import com.anu.service.EmployeeService;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
	@Autowired
	EmployeeService empService;
	
	@RequestMapping("/getData")
	public String showEmployeeDetails(Model model)
	{
		List <Employee> employees = empService.getAllEmployeesSvc();
		model.addAttribute("myEmployees", employees);
		return "employees";
	}

}
