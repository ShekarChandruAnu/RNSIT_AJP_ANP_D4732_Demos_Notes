package com.anu.rnsitspringmvc;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
	
	@RequestMapping("/greet")
	public String sayHello(Model model)
	{
		String message = "Welcome to SPRINGBoot based MVC applications";
		model.addAttribute("mymessage", message);
		return "welcome";
	}
	
	

}
