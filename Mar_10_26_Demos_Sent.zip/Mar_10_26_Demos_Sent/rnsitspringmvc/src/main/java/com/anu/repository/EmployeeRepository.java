package com.anu.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.anu.model.Employee;

@Repository
public class EmployeeRepository {
	
	
	List <Employee> employees;
	
	public EmployeeRepository()
	{
		employees = new ArrayList<Employee>();
	}
	
	public List <Employee> getAllEmployees()
	{
		employees.add(new Employee("E001","Harsha","RTNagar","8499499499","harsha@gmail.com"));
		employees.add(new Employee("E002","SreeHarsha","JayaNagar","8495699499","sreeharsha@gmail.com"));
		employees.add(new Employee("E003","Harshitha","VijayaNagar","8499497899","harshith@gmail.com"));
		employees.add(new Employee("E004","Rakesh Kumara","IndiraNagar","8454499499","rakesh@gmail.com"));
		employees.add(new Employee("E005","Sumanth","Malleswaram","8499499789","sumanth@gmail.com"));
		return employees;
	}

}
