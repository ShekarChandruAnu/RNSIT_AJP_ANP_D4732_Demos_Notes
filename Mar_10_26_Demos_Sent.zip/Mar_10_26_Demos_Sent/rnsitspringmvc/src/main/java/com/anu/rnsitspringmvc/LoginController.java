package com.anu.rnsitspringmvc;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.anu.model.Login;

@Controller
@RequestMapping("/login")
public class LoginController {

	@RequestMapping("/showLoginPage")
	public String loadLoginPage(Model model)
	{
		Login login = new Login();
		model.addAttribute("login", login);
		return "loginPage";
	}
	/**/
	@RequestMapping("/authenticate")
	public String validateLogin(@ModelAttribute Login login,Model model)
	{
		//This should actually invoke a Service in turn service to invoke a Repository which talks to DBMS
		if(login.getLoginId().equals("admin") && login.getPassword().equals("password"))
		{
			model.addAttribute("login", login);
			return "success";
		}
		else
		{
			return "failedPage";
		}
		
	}
}
