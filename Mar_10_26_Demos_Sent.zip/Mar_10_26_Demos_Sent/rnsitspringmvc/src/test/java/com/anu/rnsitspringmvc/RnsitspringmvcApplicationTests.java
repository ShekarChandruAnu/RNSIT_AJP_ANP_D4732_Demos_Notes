package com.anu.rnsitspringmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RnsitspringmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
