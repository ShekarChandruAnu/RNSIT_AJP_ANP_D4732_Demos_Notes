package com.anu.rnsit;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.anu.rnsit.model.Employee;
import com.anu.rnsit.service.EmployeeService;

@Controller
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	EmployeeService empService;
	
	@RequestMapping("/getData")
	public String viewEmployees(Model model)
	{
		List <Employee> employees = empService.getEmployeesSvc();
		model.addAttribute("myEmployees", employees);
		return "employees";
	}
}
