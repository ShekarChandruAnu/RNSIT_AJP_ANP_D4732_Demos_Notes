package com.anu.rnsit.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.anu.rnsit.model.Employee;

@Repository
public class EmployeeRepo {

	List <Employee> employees;
	
	public EmployeeRepo()
	{
		employees = new ArrayList<Employee>();
	}
	public List <Employee> getEmployees()
	{
		employees.add(new Employee("E001","Harsha","RTNagar"));
		employees.add(new Employee("E002","SreeHarsha","JayaNagar"));
		employees.add(new Employee("E003","Kiran Kumar","VijayaNagar"));
		employees.add(new Employee("E004","Rajesh Kumar","IndiraNagar"));
		employees.add(new Employee("E005","Rajendra ","Koramangala"));
		return employees;
	}
}
