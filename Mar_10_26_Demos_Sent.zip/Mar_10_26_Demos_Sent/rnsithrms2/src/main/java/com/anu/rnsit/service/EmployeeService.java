package com.anu.rnsit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anu.rnsit.model.Employee;
import com.anu.rnsit.repository.EmployeeRepo;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepo empRepo;
	
	public List <Employee> getEmployeesSvc()
	{
		return empRepo.getEmployees();
	}
}
