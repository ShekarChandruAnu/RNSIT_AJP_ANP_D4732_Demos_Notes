<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<h2>Welcome ${login.loginId}</h2>
<h3>View Employee Details.... By Clicking Below...</h3>
<a href="/rnsithrms2/employees/getData">View Employees Data</a>
</body>
</html>