<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="yellow">
<ul>
<c:forEach items="${myEmployees}" var="employee">
<li>${employee.empId} :: ${employee.empName} :: ${employee.empAddress}</li>

</c:forEach>
</ul>
<a href="/rnsithrms2/login/showLoginPage">Go To Login Page...</a>
</body>
</html>