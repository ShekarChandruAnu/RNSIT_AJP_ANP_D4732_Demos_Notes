<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="Red">
<h2></h2>
Sorry Invalid Credentials
<a href="/rnsithrms2/login/showLoginPage">Go To Login Page...</a>
</body>
</html>