<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<h2>Welcome to Spring MVC Mavenized apps...</h2>
<h3>${mymessage}</h3>
<a href="/rnsithrms2/login/showLoginPage">Go To Login Page...</a>
</body>
</html>