<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %> 
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body bgcolor="aqua">
<form:form action="/rnsithrms2/login/authenticate" modelAttribute="login">
Enter Login Id <form:input path="loginId"/></br>
Enter Password <form:password path="password"/></br>
<input type="submit" value="Login" />

</form:form>
</body>
</html>