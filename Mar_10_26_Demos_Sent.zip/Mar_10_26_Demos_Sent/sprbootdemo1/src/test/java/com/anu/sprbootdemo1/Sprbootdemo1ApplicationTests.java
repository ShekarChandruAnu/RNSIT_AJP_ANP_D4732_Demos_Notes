package com.anu.sprbootdemo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sprbootdemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
