package com.anu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MyController {

	@GetMapping("/sayHi")
	public String sayHello(Model model)
	{
		model.addAttribute("message", "Welcome to SpringBoot apps");
		return "welcome";
		
	}
}
