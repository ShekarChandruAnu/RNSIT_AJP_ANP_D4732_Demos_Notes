package com.anu.sprbootdemo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.*")
public class Sprbootdemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Sprbootdemo1Application.class, args);
		System.out.println("Hi Successfully started ...");
	}

}
