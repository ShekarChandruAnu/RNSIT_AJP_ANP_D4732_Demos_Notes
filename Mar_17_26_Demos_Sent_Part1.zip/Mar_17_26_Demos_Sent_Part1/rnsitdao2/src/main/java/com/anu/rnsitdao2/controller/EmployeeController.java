package com.anu.rnsitdao2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.anu.rnsitdao2.model.RnsitEmployee;
import com.anu.rnsitdao2.service.EmployeeService;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
	
	@Autowired
	EmployeeService empService;
	//EmployeeServiceImpl empServicImpl;
	
	
	@GetMapping("/allEmployees")
	public String getAllEmployees(Model model)
	{
		List <RnsitEmployee> employees = empService.getAllEmployeesSvc();
		model.addAttribute("employees", employees);
		return "employeesList";
	}
	/*
	@GetMapping("/getEmployeeById")
	public String getEmployeeById(@RequestParam int empId,Model model)
	{
		RnsitEmployee rnsitEmployee = empService.getEmployeeByIdSvc(empId);
		model.addAttribute("employee", rnsitEmployee);
	}*/
	@GetMapping("/showFormForAdd")
	public String showFormToAddRecord(Model model)
	{
		RnsitEmployee rnsitEmployee = new RnsitEmployee();
		model.addAttribute("employee", rnsitEmployee);
		return "employeeForm";
	}
	
	@PostMapping("/showFormForUpdate")
	public String showFormToUpdate(Model model,@RequestParam int empId)
	{
		RnsitEmployee rnsitEmployee = empService.getEmployeeByIdSvc(empId);
		model.addAttribute("employee", rnsitEmployee);
		return "employeeForm";
	}
	
	@PostMapping("/saveEmployee")
	public String saveRecord(@ModelAttribute RnsitEmployee employee)
	{
		empService.saveRnsitEmployee(employee);
		return "redirect:/employees/allEmployees";
	}
	@PostMapping("/deleteEmployee")
	public String deleteRecord(@RequestParam int empId)
	{
		empService.deleteRnsitEmployeeById(empId);
		return "redirect:/employees/allEmployees";
	}

}
