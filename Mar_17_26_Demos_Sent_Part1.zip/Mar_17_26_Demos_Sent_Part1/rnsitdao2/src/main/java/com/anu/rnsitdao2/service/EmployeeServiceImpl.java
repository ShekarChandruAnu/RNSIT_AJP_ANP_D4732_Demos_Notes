package com.anu.rnsitdao2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anu.rnsitdao2.dao.EmployeeRepository;
import com.anu.rnsitdao2.model.RnsitEmployee;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	//EmployeeRepository empRepo = new EmployeeRepository();
	
	@Autowired
	EmployeeRepository empRepo;
	
	@Override
	public List<RnsitEmployee> getAllEmployeesSvc() {
		// TODO Auto-generated method stub
		return empRepo.findAll();
	}

	@Override
	public RnsitEmployee getEmployeeByIdSvc(int id) {
		// TODO Auto-generated method stub
		Optional <RnsitEmployee> rnsitEmployee = empRepo.findById(id);
		if(rnsitEmployee.isPresent())
		{
			return rnsitEmployee.get();
		}
		else
		{
			throw new RuntimeException("Employee Not found for id "+id);
		}
		
	}

	@Override
	public void saveRnsitEmployee(RnsitEmployee rnsitEmployee) {
		// TODO Auto-generated method stub
		empRepo.save(rnsitEmployee);
	}

	@Override
	public void deleteRnsitEmployeeById(int id) {
		// TODO Auto-generated method stub
		empRepo.deleteById(id);
	}

}
