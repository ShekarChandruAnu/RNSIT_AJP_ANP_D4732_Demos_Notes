package com.anu.rnsitdao2.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anu.rnsitdao2.model.RnsitEmployee;

//@Repository
public interface EmployeeRepository extends JpaRepository <RnsitEmployee,Integer>{
/*
 * CRUD Operations PREDEFINED FOR US
 * Only additional customizations need to be defined
 */
}
