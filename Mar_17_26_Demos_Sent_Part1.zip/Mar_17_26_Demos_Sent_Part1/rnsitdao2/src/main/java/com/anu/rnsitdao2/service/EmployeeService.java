package com.anu.rnsitdao2.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.anu.rnsitdao2.model.RnsitEmployee;

@Service
public interface EmployeeService {

	public List <RnsitEmployee> getAllEmployeesSvc();
	public RnsitEmployee getEmployeeByIdSvc(int id);
	public void saveRnsitEmployee(RnsitEmployee rnsitEmployee);
	public void deleteRnsitEmployeeById(int id);
	
}
