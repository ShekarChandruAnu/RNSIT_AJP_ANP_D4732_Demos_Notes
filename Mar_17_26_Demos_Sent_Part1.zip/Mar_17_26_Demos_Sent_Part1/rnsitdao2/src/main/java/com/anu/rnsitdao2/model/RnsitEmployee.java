package com.anu.rnsitdao2.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="rnsitemployee")
public class RnsitEmployee {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	int id;
	
	@Column(name="emp_Name")
	String empName;
	
	@Column(name="address")
	String address;
	
	@Column(name="department")
	String department;
	
	@Column(name="designation")
	String designation;
	
	@Column(name="salary")
	int salary;

}
