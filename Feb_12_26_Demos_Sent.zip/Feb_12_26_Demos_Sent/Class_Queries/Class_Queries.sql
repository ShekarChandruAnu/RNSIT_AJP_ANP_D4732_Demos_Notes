create Database RNSIT;
use RNSIT;

create table Employee
(
empId varchar(20) primary key ,
empName varchar(50),
empAddress varchar(100),
empPhone varchar(50),
empSalary int,
empDOJ date
);
select * from Employee;

create table NewEmployee
as
select * from Employee ;

select * from NewEmployee;

update newEmployee
set employeeAddress = 'Jayanagar',
employeeSalary = 20000 where employeeId = 'E001';
select * from employee;
delete from NewEmployee where employeeId = 'E002';
-- vs
delete from NewEmployee;
select * from NewEmployee;

insert into NewEmployee
values
('E001','Harshitha','Koramangala','9839393993',20000,'2024-12-23',12.34);
select * from NewEmployee;

describe NewEmployee;

select * from Employee;
create table NewEmployee1
as
select * from Employee;

select * from NewEmployee1;

use rnsit;

select * from Employee;

create table NewEmployee
as
select * from Employee;




select * from NewEmployee;

insert into NewEmployee
values
('E001','Kiran Kumar','Malleswaram','8939939393',25000,'2023-06-21');

select * from NewEmployee;

delete from NewEmployee;
select * from NewEmployee;
drop table NewEmployee;
use rnsit;

truncate table NewEmployee;
-- GROUP BY
create table Movies
(
MovieId varchar(20) primary key,
MovieCategory varchar(30),
MovieName varchar(20),
Collections int);

drop table Movies;
insert into Movies
values
('M1','Comedy','HAHK',450000),
('M2','Tragedy','HSKK',550000),
('M3','Drama','JHGK',650000),
('M4','Comedy','STRA',750000),
('M5','Drama','LKAP',850000),
('M6','Comedy','WRTS',950000),
('M7','Drama','NJFMSD',350000),
('M8','Tragedy','SKJD',850000),
('M9','Comedy','KJHA',1250000),
('M10','Tragedy','SIYT',1150000),
('M11','Action','OUAY',750000),
('M12','Tragedy','LKAP',900000),
('M13','Action','SMNX',1100000);
select * from Movies;

select MovieCategory,
avg(Collections) as 'Average Collections',
max(Collections) as 'Maximum Collections',
min(Collections) as 'Minimum Collections',
sum(Collections) as 'Total Collections'
from Movies
group by MovieCategory;

select MovieCategory,
avg(Collections) as 'Average Collections',
max(Collections) as 'Maximum Collections',
min(Collections) as 'Minimum Collections',
sum(Collections) as 'Total Collections'
from Movies
group by MovieCategory having avg(Collections) > 850000;

/*
select concat('hello','world','new');

select concat(sFirstName,sLastName) as 'Supplier FullName' from Supplier;

select insert("Internet",4,3,'mission');

select instr('Internet','net');

select field('three','two','three','two','four','four');

select reverse('hello');

select ltrim('      hello');

select substring('hello world',3,6);

select replace('hello world','o','p');

select left('world over',4);

select right('world over',4);

select space(5);

*/
select concat('hello','world','new');

create table Student
(
studId varchar(20),
firstName varchar(50),
lastName varchar(50),
Course varchar(50)
);

insert into Student
values
('S001','Rajan','Gupta','MCA'),
('S002','Kiran','Sharma','BCA'),
('S003','Rajat','Khurana','BTech'),
('S004','Rajan','Verma','MCA'),
('S005','Rajesh','Sinha','BTech');
select * from Student;

select concat(firstName,' ',lastName) as 'Full Name',course from Student;

select concat(firstName,space(2),lastName) as 'Full Name',course from Student;
select insert("Internet",4,3,'mission');
select substring('hello world',3,6);
select substring(firstName,1,1) as 'Initials',lastName , course from Student;

select concat(substring(firstName,1,1) ,'.',lastName) as 'FullName' , course from Student;

select concat(upper(substring(firstName,1,1)) ,'.',lastName) as 'FullName' , course from Student;

select ltrim('      hello');

select reverse('hello');
select instr('Internet','net');
select left('world over',4);
select right('world over',4);
select field('three','two','three','two','four','four');
select field('four','two','three','two','four','four');
select upper('hello');


select strcmp('harsha','harshit');

select ascii('h');

select upper(sFirstname) from supplier;
-- MATH FUNCTIONS
select ceil(2.3456);
select floor(2.3456);
select log10(100);
select mod(245,10);

select 245 mod 10;
select radians(90);
select round(degrees(1.57));
select round(sin(1.57));
select pow(2,3);
select sqrt(144);
--    DATE FUNCTIONS
# Currrent Date
select curdate();
# Current Date & Time
select now();
#Current Time only
select curtime();
select * from Employee;

select empName,
empDOJ as 'Date Of Joining' , 
datediff(curdate(),empDOJ) as 'NoOfDays Since Joined'  
from employee;

select empName,
empDOJ as 'Date Of Joining' , 
datediff(curdate(),empDOJ) as 'NoOfDays Since Joined'  ,
datediff(curDate(),empDOJ)/365 as 'No of Years Since Joined',
datediff(curDate(),empDOJ)/365 * 12 as 'No of Months Since Joined'
from employee;

select date_add(curdate(),interval 2 year);
select date_add(curdate(),interval 2 day);

select date_add(curdate(),interval 2  QUARTER);

select date_sub(curdate(),interval 25 day);

select date_sub(curdate(),interval 2 YEAR);

-- PRIMARY KEY WHILE CREATING TABLE

create table Students
(
studentId varchar(20) primary key,
studentName varchar(50),
studentAddress varchar(50),
studentCourse varchar(50)
);
-- PRIMARY KEY WHILE CREATING TABLE but after specifying column
create table Students1
(
studentId varchar(20),
studentName varchar(50),
studentAddress varchar(50),
studentCourse varchar(50),
constraint cpKey1 primary key(studentId)
);
describe Students1;
insert into Students1
values('S001','Keerthana','RTNagar','MCA');

create table Students2
(
studentId varchar(20),
studentName varchar(50),
studentAddress varchar(50),
studentCourse varchar(50)
);

insert into Students2
values
('S001','Keerthana','RTNagar','MCA'),
('S001','Sumanth','RTNagar','MCA');

select * from Students2;

update  Students2
set studentId = 'S002' where studentName = 'Sumanth';

alter table Students2
add constraint priKey1 primary key(studentId);






