select * from employees;
select * from employees where employeeSalary <
(select max(employeeSalary) from employees)
order by employeeSalary desc limit 1 ;

create table LessThanMaxSalary as
select * from employees where employeeSalary <
(select max(employeeSalary) from employees);

select * from LessThanMaxSalary;