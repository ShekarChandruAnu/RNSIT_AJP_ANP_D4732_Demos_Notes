package com.anu.rns;

public interface Account extends CreditCardAccount,DebitCardAccount{
	public void createAccount();
	public void closeAccount();
}
