package com.anu.rns;

public class MyAccount implements  Account,InsuranceAccount{

	
	@Override
	public void calculateRedemptionPoints() {
		// TODO Auto-generated method stub
		System.out.println("Redemption Points Calculated...");
		
	}

	@Override
	public void calculateOutstandingAmt() {
		// TODO Auto-generated method stub
		System.out.println("Outstanding Amount Calculated...");
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		System.out.println("Deposited Amount successfully...");
	}

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		System.out.println("Withdrawn AMount successfully...");
		
	}

	@Override
	public void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println("Balance in SB Account is ....");
		
	}

	@Override
	public void createPolicy() {
		// TODO Auto-generated method stub
		System.out.println("Policy Created successfully....");
		
	}

	@Override
	public void terminatePolicy() {
		// TODO Auto-generated method stub
		System.out.println("Terminated Policy Successfully...");
		
	}

	@Override
	public void calculatePremium() {
		// TODO Auto-generated method stub
		System.out.println("Premium Calculated is ....");
		
	}

	@Override
	public void createAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account Created successfully...");
		
	}

	@Override
	public void closeAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account Closed Successfully...");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyAccount mac = new MyAccount();
		//ACcount related
		mac.createAccount();
		//CreditCard Related
		mac.calculateOutstandingAmt();
		mac.calculateRedemptionPoints();
		//Debit Card Related
		mac.checkBalance();
		mac.deposit();
		mac.withdraw();
		//Insurance related
		mac.createPolicy();
		mac.calculatePremium();
		mac.terminatePolicy();
		
		mac.closeAccount();

	}


}
