package com.anu.rns;

public interface CreditCardAccount {
	
	public void calculateRedemptionPoints();
	public void calculateOutstandingAmt();

}
