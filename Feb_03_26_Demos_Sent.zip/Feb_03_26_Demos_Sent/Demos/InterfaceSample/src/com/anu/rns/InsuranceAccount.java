package com.anu.rns;

public interface InsuranceAccount {

	public void createPolicy();
	public void terminatePolicy();
	public void calculatePremium();
	
}
