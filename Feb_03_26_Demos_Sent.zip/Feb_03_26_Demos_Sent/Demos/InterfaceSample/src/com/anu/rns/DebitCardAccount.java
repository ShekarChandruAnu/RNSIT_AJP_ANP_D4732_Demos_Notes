package com.anu.rns;

public interface DebitCardAccount {
	public void deposit();
	public void withdraw();
	public void checkBalance();

}
