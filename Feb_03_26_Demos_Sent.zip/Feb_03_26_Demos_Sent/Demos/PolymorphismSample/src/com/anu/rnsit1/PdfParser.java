package com.anu.rnsit1;

public class PdfParser extends Parser{

	@Override
	public void parse(String fileType)
	{
		System.out.println("Parsing Completed for the Type "+fileType);
	}

	

}
