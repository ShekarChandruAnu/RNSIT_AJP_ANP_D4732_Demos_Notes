package com.anu.rnsit1;

public class XmlParser extends Parser{

	@Override
	public void parse(String fileType) {
		// TODO Auto-generated method stub
		System.out.println("Parsing Completed for the Type "+fileType);
	}

}
