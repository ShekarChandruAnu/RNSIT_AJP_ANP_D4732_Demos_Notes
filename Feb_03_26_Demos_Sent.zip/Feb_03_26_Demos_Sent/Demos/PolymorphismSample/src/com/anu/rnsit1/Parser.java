package com.anu.rnsit1;

public abstract class Parser {
	
	public abstract void parse(String fileType);
	public void displayParser()
	{
		System.out.println("The Parser Details are as follows....");
	}

}
