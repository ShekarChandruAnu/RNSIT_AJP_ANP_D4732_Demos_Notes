package com.anu.rnsit1;

public class ParserUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Parser myParser;// = new Parser();
		myParser = new XmlParser();
		myParser.parse("XML File");
		
		myParser = new JsonParser();
		myParser.parse("JSON File");
		
		myParser = new PdfParser();
		myParser.parse("PDF File");
		myParser.displayParser();

	}

}
