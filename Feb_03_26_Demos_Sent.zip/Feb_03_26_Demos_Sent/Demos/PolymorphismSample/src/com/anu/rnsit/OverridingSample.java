package com.anu.rnsit;
class Base
{
	public void display()
	{
		System.out.println("Displaying Base Class Features");
	}
	
}
class Derived extends Base
{
	public void display()
	{
		System.out.println("Displaying Derived Class Features");
	}
}
public class OverridingSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Derived d1 = new Derived();
		d1.display();
		d1.display();

	}

}
