package com.anu.rnsit;

public class MethodOverLoadingSample {

	double grossSalary;
	public void calculateSalary(double basic,double hra,double cca)
	{
		grossSalary = basic + hra + cca;
		System.out.println("Gross Salary is "+grossSalary);
	}
	public void calculateSalary(double basic,double hra,double cca,double deductions,String empName)
	{
		double nettSalary = (basic+ hra + cca) - (deductions);
		grossSalary = (basic + hra + cca);
		System.out.println("The Gross Salary for "+empName+" is "+grossSalary);
		System.out.println("The NettSalary for "+empName+" is "+nettSalary);
	}
	public void calculateSalary(double basic,double hra,double cca,double deductions,double allowances,String empName)
	{
		grossSalary = (basic + hra + cca + allowances);
		double nettSalary = (basic + hra + cca + allowances)- deductions;
		System.out.println("The Gross with Allowances for "+empName+" is "+grossSalary);
		System.out.println("Nett Salary including allowances for "+empName+" is "+nettSalary);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOverLoadingSample mols = new MethodOverLoadingSample();
		mols.calculateSalary(1000, 250, 350);
		mols.calculateSalary(1000, 250, 350, 300, "Harsha");
		mols.calculateSalary(1000, 250, 350, 300, 400, "Harsha");
		System.out.println("---------");
		mols.calculateSalary(2000, 450, 350);
		mols.calculateSalary(2000, 450, 350, 400, "Harsha");
		mols.calculateSalary(2000, 450, 350, 400, 600, "Harsha");
		

	}

}
