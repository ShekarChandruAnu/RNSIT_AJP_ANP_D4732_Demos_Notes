package com.anu.rnsit;

public class CheckOverlOverLoading {

	public void add(int a,int b,int c)
	{
		
	}
	public void add(int a,int b,int c,float f)
	{
		
	}
	public void add(int a,float f1,int b,int c)
	{
		
	}
	/*public float add(int a,float f1,int b,int c)
	{
		
	}*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
