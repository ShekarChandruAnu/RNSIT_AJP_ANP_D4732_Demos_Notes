package com.anu.rns1;

public class Recruitment {

	public void checkAge(int age) throws InvalidAgeException
	{
		System.out.println("Age Scrutiny Started....");
		if( (age < 20) || (age > 30))
		{
			 /*InvalidAgeException iae = new InvalidAgeException("Sorry Valid Age Range is 20-30");
			throw iae;*/
			throw new InvalidAgeException("Sorry Valid Age Range is 20-30");
		}
		System.out.println("Age is "+age+" Valid Age ");
		System.out.println("Age Scrutiny Completed...Further Recruitment Process to continue..");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Recruitment Process Started...");
		Recruitment rc = new Recruitment();
		try
		{
			rc.checkAge(25);
			rc.checkAge(26);
			rc.checkAge(32);
			rc.checkAge(21);
			rc.checkAge(24);
		}
		catch(InvalidAgeException iae)
		{
			System.out.println(iae.message);
			iae.printStackTrace();
		}
		System.out.println("Recruitment Process completed.");

	}

}
