package com.anu.rns1;

public class NewRecruitment {
	public void callCheckAge(int age)
	{
		try
		{
			checkAge(age);
		}
		catch(InvalidAgeException iae)
		{
			System.out.println("Invalid Age "+age);
			iae.printStackTrace();
			System.out.println(iae.message);
		}
	}
	public void checkAge(int age) throws InvalidAgeException
	{
		System.out.println("Age Scrutiny Started....");
		if( (age < 20) || (age > 30))
		{
			 /*InvalidAgeException iae = new InvalidAgeException("Sorry Valid Age Range is 20-30");
			throw iae;*/
			throw new InvalidAgeException("Sorry Valid Age Range is 20-30");
		}
		System.out.println("Age is "+age+" Valid Age ");
		System.out.println("Age Scrutiny Completed...Further Recruitment Process to continue..");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Recruitment Process Started...");
		NewRecruitment rc = new NewRecruitment();
	/*	try
		{*/
			rc.callCheckAge(25);
			rc.callCheckAge(26);
			rc.callCheckAge(32);
			rc.callCheckAge(21);
			rc.callCheckAge(24);
		/*}
		catch(InvalidAgeException iae)
		{
			System.out.println(iae.message);
			iae.printStackTrace();
		}*/
		System.out.println("Recruitment Process completed.");

	}

}
