package com.anu.rnsit;

public class ArrayIndexExceptionSample {

	public void manipulateArray()
	{
		int arr[] = new int[10];
		System.out.println("Inside the Array Manipulation Method..");
		try
		{
			for(int i=0;i<=10;i++)
			{
				arr[i] = (i+1)*100;
				System.out.println("Array Element is "+arr[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException aix)
		{
			aix.printStackTrace();
			//aix.getMessage();
		}
		
		System.out.println("Completed Array Manipulation...");
		System.out.println("Exiting Array Manipulation Method...");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("About to invoke Array Manipulation Method");
		ArrayIndexExceptionSample ais = new ArrayIndexExceptionSample();
		ais.manipulateArray();
	/*	try
		{
			ais.manipulateArray();
		}*/
		/*catch(ArrayIndexOutOfBoundsException cxf)
		{
			cxf.printStackTrace();
		}*/
		System.out.println("Finished array Manipulation ");
		System.out.println("Exiting Main");

	}

}
