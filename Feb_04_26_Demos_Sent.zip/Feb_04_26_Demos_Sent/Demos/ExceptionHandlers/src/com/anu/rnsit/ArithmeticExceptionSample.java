package com.anu.rnsit;

public class ArithmeticExceptionSample {
	
	public void divideSample(int num1,int num2)
	{
		int result=0;
		System.out.println("Inside the DivideSample Method...");
		try
		{
			result = num1 / num2;
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		}
		System.out.println("Result is "+result);
		System.out.println("Exiting the DivideSample Method...");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArithmeticExceptionSample aes = new ArithmeticExceptionSample();
		System.out.println("About to invoke Division Method...");
	/*	try
		{*/
			aes.divideSample(100, 20);
			aes.divideSample(100, 50);
			aes.divideSample(100, 0);
			aes.divideSample(100, 25);
			aes.divideSample(100, 10);
	/*	}
		catch(ArithmeticException ae)
		{
			//ae.getMessage();
			ae.printStackTrace();
		}*/
		System.out.println("Division invocation completed...");
		System.out.println("Exiting Main....");

	}

}
