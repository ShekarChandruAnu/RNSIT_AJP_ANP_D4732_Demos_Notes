package com.anu.rnsit;

public class StaticSample {

	int nonStaticVar;
	static int staticVar;
	// static variables can be accessible only by static methods
	// non static variables can be accessible by both static & non static methods
	public static void staticMethod1()
	{
		//nonStaticVar++;
		staticVar++;
		System.out.println("Static Variable in StaticMethod1  :"+staticVar); //1
	}
	public void nonStaticMethod1()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("Static Variable in NonStaticMethod1  :"+staticVar);//
		System.out.println("Non Static Variable in NonStaticMethod1  :"+nonStaticVar);//
	}
	public static void staticMethod2()
	{
		staticVar++;
		System.out.println("Static Variable in StaticMethod2  :"+staticVar); //1
		
	}
	public void nonStaticMethod2()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("Static Variable in NonStaticMethod2  :"+staticVar);//
		System.out.println("Non Static Variable in NonStaticMethod2  :"+nonStaticVar);//
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticSample stat1 = new StaticSample();
		StaticSample.staticMethod1();//stat:1
		//stat1.staticMethod1();
		//staticMethod1();
		stat1.nonStaticMethod1(); //stat:2   nonstat:1
		stat1.nonStaticMethod2();//stat:3 nonstat:2
		
		StaticSample stat2 = new StaticSample();
		StaticSample.staticMethod2();//stat:4
		stat2.nonStaticMethod1();//stat:5 nonstat:3
		stat2.nonStaticMethod2();//stat:6 nonstat:4

	}

}
