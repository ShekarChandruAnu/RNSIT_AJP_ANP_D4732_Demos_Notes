package rnsithrms;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/greet")
public class MyController {

	
	@RequestMapping("/sayHi")
	public String sayHello(Model model)
	{
		String message = "We are creating SPRING MVC Projects";
		model.addAttribute("mymessage", message);
		return "welcome";
	}
}
