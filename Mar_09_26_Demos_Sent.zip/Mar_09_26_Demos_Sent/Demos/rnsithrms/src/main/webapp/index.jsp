<html>
<body bgcolor="yellow">
<h2><%= "Hello World!" %></h2>
<h2>Welcome to MAVEN BASED PROJECT</h2>
<a href="/rnsithrms/greet/sayHi">Get Greeted!!!</a>
</body>
</html>
