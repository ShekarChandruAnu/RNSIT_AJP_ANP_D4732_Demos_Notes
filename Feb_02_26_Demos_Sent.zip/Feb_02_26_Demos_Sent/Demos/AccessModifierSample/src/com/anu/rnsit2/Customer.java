package com.anu.rnsit2;

import com.anu.rnsit1.Employee;

public class Customer {
	
	Employee e1 = new Employee();
	public void displayCustomer()
	{   //private cannot be accessible
		//System.out.println("Employee Address "+empAddress);
		
		//Default access check outside package-Not accessible outside package w/o instance
		// System.out.println("Employee Name"+empName);
		
		//Default cannot be access out side the package even with instance
		//System.out.println("Employee Name"+e1.empName);
		
		//Public access anywhere within / outside /derived but
				//except derived need Object/instance
				System.out.println("Employee Tax "+e1.empTax);
				//NO ACCESS TO PUBLIC OUTSIDE W/O instance
				//System.out.println("Employee Tax "+empTax);
	}

}
