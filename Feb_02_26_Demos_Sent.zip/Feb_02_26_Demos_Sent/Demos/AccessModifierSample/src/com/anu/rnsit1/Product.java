package com.anu.rnsit1;

public class Product {
	
	private String productId;
	public String productName;
	protected String productDescription;
	String productCategory;
	
	public void displayProductDetails()
	{
		Employee emp1 = new Employee();
		//private datamember of another class not accessible
		//Default can be accessible in other class in same package
		//with the help of Objects
		System.out.println("Employee Name "+emp1.empName);
		
		//Protected cannote be accessed in non derived class without instance
		//System.out.println("Phone of the Employee "+empPhone);
		System.out.println("Phone of the employee "+emp1.empPhone);
		
		//Public access anywhere within / outside /derived but
		//except derived need Object/instance
		System.out.println("Employee Tax "+emp1.empTax);
	}

}
