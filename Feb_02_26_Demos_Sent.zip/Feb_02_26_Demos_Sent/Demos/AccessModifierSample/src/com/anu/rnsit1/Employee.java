package com.anu.rnsit1;

public class Employee {
	
	String empName;
	private String empAddress;
	public String empTax;
	protected String empPhone;
	public void displayEmployeeDetails()
	{
		System.out.println("Displaying Employee Details");
	}

}
