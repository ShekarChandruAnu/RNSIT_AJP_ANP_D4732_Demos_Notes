package com.anu.rnsit1;

public class SoftwareEngineer extends Employee{

	int empCode;
	public void displaySoftwareEngineer()
	{
		System.out.println("Employee Name "+empName);
		//empAddress Not accessible - private in parent class
		//even derived class cannot access private data members
		
		//System.out.println("Employee Address "+empAddress);
		//Even with an instance we cannot access private data member
		//System.out.println("Employee Address "+super.empAddress);
		
		//public accessible anywhere
		System.out.println("Employee Tax is "+empTax);
		
		//protected accessible within derived class
		System.out.println("Employee Phone "+empPhone);
	}
}
