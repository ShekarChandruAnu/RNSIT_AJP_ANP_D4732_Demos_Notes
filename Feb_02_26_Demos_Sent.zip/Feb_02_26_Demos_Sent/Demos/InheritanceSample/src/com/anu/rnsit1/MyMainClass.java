package com.anu.rnsit1;

public class MyMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BaseClass bc = new BaseClass(); //ACCEPTED
		bc.displayBaseClass();
		DerivedClass dc = new DerivedClass();//ACCEPTED
		dc.displayBaseClass();
		
		//baseClass pointing to Derived Class - ACCEPTED
		BaseClass bc1 = new DerivedClass();
		bc1.displayBaseClass();
		
		// Derived class holding reference of Base class
		// compatibility fails NOT ACCEPTED
	//	DerivedClass dc1 = new BaseClass();
		// NOT SUGGESTED TO DO THE FOLLOWING
		DerivedClass dc1 = (DerivedClass)new BaseClass(); // COMPILATION-WISE ACCEPTED
		
		
		
		

	}

}
