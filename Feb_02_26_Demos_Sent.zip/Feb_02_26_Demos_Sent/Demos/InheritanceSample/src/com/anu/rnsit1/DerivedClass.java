package com.anu.rnsit1;

public class DerivedClass extends BaseClass{
	
	public void displayDerivedClass()
	{
		System.out.println("Displaying Derived Class Features");
	}

}
