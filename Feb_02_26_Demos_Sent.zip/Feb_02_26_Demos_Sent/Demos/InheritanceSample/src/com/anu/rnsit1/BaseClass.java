package com.anu.rnsit1;

public class BaseClass {
	
	public void displayBaseClass()
	{
		System.out.println("Displaying Base Class Features...");
	}

}
