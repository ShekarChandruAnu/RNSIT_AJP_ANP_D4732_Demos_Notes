package com.anu.rnsit;

public class FurnitureShop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookShelf bShelf1 = new BookShelf();
		bShelf1.acceptBookShelfDetails();
		bShelf1.displayBookShelfDetails();
		// Furniture Details displayed
		System.out.println("---Furniture Detail s alone----");
		Furniture furniture1 = new Furniture();
		furniture1.acceptFurnitureDetails();
		furniture1.displayFurnitureDetails();
		
		

	}

}
