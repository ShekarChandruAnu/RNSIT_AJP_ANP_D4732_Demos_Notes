package com.anu.rnsit;

import java.util.Scanner;

public class Furniture {
	
	protected int length;
	protected int width;
	protected int height;
	protected Scanner scan1 = new Scanner(System.in);
	
	public void acceptFurnitureDetails()
	{
		System.out.println("Enter Furniture Details");
		System.out.println("Enter the Length ");
		length = scan1.nextInt();
		
		System.out.println("Enter the Width ");
		width = scan1.nextInt();
		
		System.out.println("Enter the Height ");
		height = scan1.nextInt();
	}
	public void displayFurnitureDetails()
	{
		System.out.println("The Furniture Details are...");
		System.out.println("Length is "+length);
		System.out.println("Width is "+width);
		System.out.println("Height is "+height);
	}

}
