package com.anu.rnsit;

public class BookShelf extends Furniture {
	
	int no_Of_Shelves;
	
	public void acceptBookShelfDetails()
	{/*
		System.out.println("Enter the length ..");
		length = scan1.nextInt();
		System.out.println("Enter the width..");
		width = scan1.nextInt();
		System.out.println("Enter the height ..");
		height = scan1.nextInt();*/
		super.acceptFurnitureDetails();
		System.out.println("Enter the No of Shelves");
		no_Of_Shelves = scan1.nextInt();
		//no_of_legs;
		
	}
	public void displayBookShelfDetails()
	{
		System.out.println("Book SHelf Details are...");
		/*System.out.println("Length is "+length);
		System.out.println("Width is "+width);
		System.out.println("Height is "+height);*/
		super.displayFurnitureDetails();
		System.out.println("No of Shelves is "+no_Of_Shelves);
	}

}
