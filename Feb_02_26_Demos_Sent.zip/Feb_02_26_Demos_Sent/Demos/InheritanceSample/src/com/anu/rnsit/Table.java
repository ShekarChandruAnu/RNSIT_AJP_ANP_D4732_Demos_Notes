package com.anu.rnsit;

public class Table extends Furniture{

}
