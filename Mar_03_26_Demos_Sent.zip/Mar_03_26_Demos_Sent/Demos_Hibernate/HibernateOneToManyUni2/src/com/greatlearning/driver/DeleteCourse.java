package com.greatlearning.driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.greatlearning.entity.Course;
import com.greatlearning.entity.Review;
import com.greatlearning.entity.Teacher;
import com.greatlearning.entity.TeacherDetails;

public class DeleteCourse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// create session factory
				SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Teacher.class)
						.addAnnotatedClass(TeacherDetails.class)
						.addAnnotatedClass(Course.class)
						 .addAnnotatedClass(Review.class)
						 .buildSessionFactory();

				// create session
				Session session = factory.getCurrentSession();

				try {

					int theCourseId=18;
					
					// start transaction
					session.beginTransaction();

					Course tempCourse = session.get(Course.class,theCourseId);
					
					if(tempCourse!=null) {
						System.out.println("Deleting : "+ tempCourse);
						
						//Note!! : it will not delete Teacher data 
					    //         as we have not provided CascadeType.ALL
						//Note: Corresponding to this Course all Reviews will be deleted
						//Course vs Review mentioned in Course  as : cascade = CascadeType.ALL
						session.delete(tempCourse);
					}
					
					

					// commit transaction
					session.getTransaction().commit();

				} finally {
					factory.close();
				}

	}

}
