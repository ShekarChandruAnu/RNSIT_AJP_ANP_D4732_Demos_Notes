package com.rnsit.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rnsit.beans.Employee;

public class EmployeeClient {
	
	public static void main(String[] args)
	{
	ApplicationContext context = new ClassPathXmlApplicationContext("employeeContext.xml");
	System.out.println("--------Displaying Employee Details--------");
	Employee employee1 = context.getBean("emp1", Employee.class);
	employee1.displayEmployeeDetails();
	System.out.println("--------");
	Employee employee2 = context.getBean("emp2", Employee.class);
	employee2.displayEmployeeDetails();
	
	}
}
