package com.rnsit.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rnsit.beans.Student;

public class StudentClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("studentContext.xml");
		Student student1 = context.getBean("stud1", Student.class);
		student1.displayStudentDetails();
		
		Student student2 = context.getBean("stud2", Student.class);
		student2.displayStudentDetails();
		
	}

}
