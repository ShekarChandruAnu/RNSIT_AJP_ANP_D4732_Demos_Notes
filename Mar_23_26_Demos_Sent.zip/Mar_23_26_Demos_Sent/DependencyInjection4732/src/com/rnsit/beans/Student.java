package com.rnsit.beans;

public class Student {
	
	String studId;
	String studName;
	String studCourse;
	float studAvgScore;
	/*
	 * No Overloaded constructor used 
	 * Used Setters/Getters
	 * since Injection is to happen through 
	 * Setter Based Injection/Property Based Injection
	 * Field based Injection
	 */
	public Student() {
		super();
	}
	public String getStudId() {
		return studId;
	}
	public void setStudId(String studId) {
		this.studId = studId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public String getStudCourse() {
		return studCourse;
	}
	public void setStudCourse(String studCourse) {
		this.studCourse = studCourse;
	}
	public float getStudAvgScore() {
		return studAvgScore;
	}
	public void setStudAvgScore(float studAvgScore) {
		this.studAvgScore = studAvgScore;
	}
	public void displayStudentDetails()
	{
		System.out.println("The Student Details ...");
		System.out.println("Student Id "+studId);
		System.out.println("Student Name "+studName);
		System.out.println("Student Course  "+studCourse);
		System.out.println("Student Avg Score "+studAvgScore);
	}
	

}
