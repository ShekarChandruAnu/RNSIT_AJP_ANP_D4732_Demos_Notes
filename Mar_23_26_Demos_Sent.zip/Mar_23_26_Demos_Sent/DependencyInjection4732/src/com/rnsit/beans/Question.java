package com.rnsit.beans;

import java.util.List;

public class Question {
	
	String questId;
	String question;
	List <Answer> answers;
	
	public Question() {
		super();
	}

	public Question(String questId, String question, List<Answer> answers) {
		super();
		this.questId = questId;
		this.question = question;
		this.answers = answers;
	}
	
	public void displayQuestionsWithAnswers()
	{
		System.out.println("Question Id :"+questId);
		System.out.println("Question is :"+question);
		System.out.println("------------Answers are-------------");
		for(Answer ans:answers)
		{
			System.out.println(ans);
		}
	}
	
	

}
