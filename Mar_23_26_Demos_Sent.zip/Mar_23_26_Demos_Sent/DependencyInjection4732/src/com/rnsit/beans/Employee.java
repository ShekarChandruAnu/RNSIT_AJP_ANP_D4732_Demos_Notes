package com.rnsit.beans;

public class Employee {
	
	String empId;
	String empName;
	String empMail;
	float empSalary;
	Address empAddress;
	
	public Employee() {
		super();
	}

	public Employee(String empId, String empName, String empMail, float empSalary, Address empAddress) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empMail = empMail;
		this.empSalary = empSalary;
		this.empAddress = empAddress;
	}
	
	public void displayEmployeeDetails()
	{
		System.out.println("Employee Details are...");
		System.out.println("Employee Id "+empId);
		System.out.println("Employee Name "+empName);
		System.out.println("Employee Mail "+empMail);
		System.out.println("Employee Salary "+empSalary);
		System.out.println("Employee Address "+empAddress);
	}
	
	
	
	

}
