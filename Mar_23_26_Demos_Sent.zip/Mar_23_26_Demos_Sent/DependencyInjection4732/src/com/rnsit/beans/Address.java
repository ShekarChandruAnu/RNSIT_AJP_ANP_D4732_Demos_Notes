package com.rnsit.beans;

public class Address {
	
	String street;
	String area;
	String city;
	String state;
	String pinCode;
	
	public Address() {
		super();
	}

	public Address(String street, String area, String city, String state, String pinCode) {
		super();
		this.street = street;
		this.area = area;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
	}

	@Override
	public String toString() {
		return "Address [street=" + street + ", area=" + area + ", city=" + city + ", state=" + state + ", pinCode="
				+ pinCode + "]";
	}
	
	

}
