package com.rnsit.beans;

public class Customer {
	
	String customerId;
	String customerName;
	String customerMail;
	float purchaseValue;
	
	public Customer() {
		super();
	}

	public Customer(String customerId, String customerName, String customerMail, float purchaseValue) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerMail = customerMail;
		this.purchaseValue = purchaseValue;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerMail="
				+ customerMail + ", purchaseValue=" + purchaseValue + "]";
	}
	
	public void displayCustomerDetails()
	{
		System.out.println("The Customer Details are...");
		System.out.println("Customer Id "+customerId);
		System.out.println("Customer Name "+customerName);
		System.out.println("Customer Mail "+customerMail);
		System.out.println("Purchase Value "+purchaseValue);
	}
	

}
