package com.anu.springthymernsit2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/greetings")
public class MyController {
	
	@RequestMapping("/sayHello")
	public String greetHello(Model model)
	{
		String myMessage = "Welcome to Thymeleaf Based SPRINGBOOT apps...";
		model.addAttribute("message", myMessage);
		return "welcome";
	}

}
