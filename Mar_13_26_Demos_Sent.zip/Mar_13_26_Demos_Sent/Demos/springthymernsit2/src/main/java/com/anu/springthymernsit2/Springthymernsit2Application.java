package com.anu.springthymernsit2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springthymernsit2Application {

	public static void main(String[] args) {
		SpringApplication.run(Springthymernsit2Application.class, args);
		System.out.println("Welcome to Thymeleaf based SPRINGBoot MVC Projects");
	}

}
