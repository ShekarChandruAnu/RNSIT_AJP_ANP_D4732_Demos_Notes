package com.anu.springthymernsit1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/greetings")
public class MyController {
	
	
	@RequestMapping("/hello")
	public String sayHello(Model model)
	{
		model.addAttribute("message", "We have loaded a Thymeleaf UI...");
		return "welcome";
		
	}

}
