package com.anu.springthymernsit1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springthymernsit1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springthymernsit1Application.class, args);
		System.out.println("Hello Welcome to SpringBoot Based - Thymeleaf UI App...");
	}

}
