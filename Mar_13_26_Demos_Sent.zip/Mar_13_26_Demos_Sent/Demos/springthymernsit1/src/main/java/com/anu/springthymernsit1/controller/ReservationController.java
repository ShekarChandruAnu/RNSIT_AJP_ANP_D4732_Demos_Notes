package com.anu.springthymernsit1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/rail")
public class ReservationController {
	
	@RequestMapping("/reserve")
	public String reserveTicket(Model model)
	{
		return "reservation.html";
	}

}
