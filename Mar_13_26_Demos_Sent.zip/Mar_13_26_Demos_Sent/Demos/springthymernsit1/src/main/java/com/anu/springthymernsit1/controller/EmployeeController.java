package com.anu.springthymernsit1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.anu.springthymernsit1.model.Employee;
import com.anu.springthymernsit1.service.EmployeeService;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
	
	@Autowired
	EmployeeService empSvc;
	
	@RequestMapping("/getData")
	public String getAllEmployees(Model model)
	{
		List <Employee> employees = empSvc.getAllEmployeesSvc();
		model.addAttribute("myEmployees", employees);
		return "employeesPage";
	}

}
