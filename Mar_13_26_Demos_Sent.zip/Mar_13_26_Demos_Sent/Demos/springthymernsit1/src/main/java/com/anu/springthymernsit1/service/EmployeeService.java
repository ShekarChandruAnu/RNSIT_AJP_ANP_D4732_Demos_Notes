package com.anu.springthymernsit1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anu.springthymernsit1.model.Employee;
import com.anu.springthymernsit1.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository empRepo;
	
	public List <Employee> getAllEmployeesSvc()
	{
		return empRepo.getAllEmployeesRepo();
	}
}
