package com.anu.springthymernsit1.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.anu.springthymernsit1.model.Employee;

@Repository
public class EmployeeRepository {

	List <Employee> employees;
	
	public EmployeeRepository()
	{
		employees = new ArrayList<Employee>();
	}
	
	public List <Employee> getAllEmployeesRepo()
	{
		employees.add(new Employee("E001","Harsha","RTNagar"));
		employees.add(new Employee("E002","SreeHarsha","JayaNagar"));
		employees.add(new Employee("E003","Kiran","VijayaNagar"));
		return employees;
	}
}
