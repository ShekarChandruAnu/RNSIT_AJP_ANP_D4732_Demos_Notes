package com.anu.rnsit;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class WriteToBinaryStream {

	byte myBytes[] = new byte[100];
	String str = "We are writing to Binary Stream";
	FileOutputStream fos;
	public void writeToBinaryStream()
	{
		try {
			myBytes = str.getBytes();
			fos = new FileOutputStream("supplier.txt");
			fos.write(myBytes);
			fos.flush();
			fos.close();
			System.out.println("Written into binary stream successfully...");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WriteToBinaryStream wbs = new WriteToBinaryStream();
		wbs.writeToBinaryStream();

	}

}
