package com.anu.rnsit;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderSample {

	FileReader fReader;
	String str ;
	int chars;
	public void readFromCharStream()
	{
		try {
			fReader = new FileReader("customer.txt");
			System.out.println("Data Read is ");
			
				while((chars= fReader.read()) != -1)
				{
					System.out.print((char)chars);
				}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileReaderSample frs = new FileReaderSample();
		frs.readFromCharStream();

	}

}
