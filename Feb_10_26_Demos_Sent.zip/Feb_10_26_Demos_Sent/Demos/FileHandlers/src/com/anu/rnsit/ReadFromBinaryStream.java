package com.anu.rnsit;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ReadFromBinaryStream {

	byte mybytes[] = new byte[100];
	FileInputStream fis;
	public void readFromBinaryStream()
	{
		try {
			fis = new FileInputStream("supplier.txt");
			fis.read(mybytes);
			String readStr = new String(mybytes);
			System.out.println("The Data Read from File :"+readStr);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReadFromBinaryStream rfbs = new ReadFromBinaryStream();
		rfbs.readFromBinaryStream();

	}

}
