package com.anu.rnsit;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterSample {

	FileWriter fWriter;
	String str = "We are writing data to char stream";
	public void writeToCharStream() //throws IOException
	{
		
			try {
				fWriter = new FileWriter("customer.txt");
				fWriter.write(str);
				fWriter.flush();
				fWriter.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("We have written the data into character stream");
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileWriterSample fwSample = new FileWriterSample();
	/*	try {*/
			fwSample.writeToCharStream();
		/*} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}

}
