package com.anu.serial;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class EmployeeDeSerializer {

	ObjectInputStream ois;
	ArrayList <Employee> dAls = new ArrayList<Employee>();
	public void deSerializeEmployee()
	{
		try {
			ois = new ObjectInputStream(new FileInputStream("employees.txt"));
			dAls = (ArrayList<Employee>) ois.readObject();
			System.out.println("DeSerialized Objects are...");
			for(Employee e:dAls)
			{
				System.out.println(e);
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDeSerializer edslr = new EmployeeDeSerializer();
		edslr.deSerializeEmployee();

	}

}
