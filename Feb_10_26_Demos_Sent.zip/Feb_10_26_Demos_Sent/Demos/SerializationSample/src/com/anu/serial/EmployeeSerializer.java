package com.anu.serial;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class EmployeeSerializer {

	ObjectOutputStream ops;
	public void serializeEmployee()
	{
		ArrayList <Employee> als = new ArrayList<Employee>();
		als.add(new Employee("E001","Harsha","RTNagar","9829292967",10000));
		als.add(new Employee("E002","Kiran","Koramangala","9829292954",12000));
		als.add(new Employee("E003","Suman","Malleswaram","9829292932",13000));
		als.add(new Employee("E004","Murali","Indiranagar","9829292989",14000));
		als.add(new Employee("E005","sree","Jayanagar","9829292912",15000));
		try {
			ops = new ObjectOutputStream(new FileOutputStream("employees.txt"));
			ops.writeObject(als);
			ops.flush();
			ops.close();
			System.out.println("Serialized Employees usccessfully...");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeSerializer eslr = new EmployeeSerializer();
		eslr.serializeEmployee();

	}

}
