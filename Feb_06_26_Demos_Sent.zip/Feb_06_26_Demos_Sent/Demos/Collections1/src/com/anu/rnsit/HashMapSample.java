package com.anu.rnsit;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HashMapSample {

	HashMap <String,Employee> empMap = new HashMap<String,Employee>();
	
	public void populateHashMap()
	{
		Employee employee1 = new Employee("E001","Harsha","RTNagar","9839393939",10000,12.34f);
		empMap.put("E001", employee1);
		empMap.put("E003", new Employee("E003","Sumanth","Jayanagar","9546393459",13000,12.34f));
		
		empMap.put("E002", new Employee("E002","SreeHarsha","Vijayanagar","9544563939",12000,13.34f));
		empMap.put("E004", new Employee("E004","Mahesh","Malleswaram","9546453939",14000,14.34f));
		empMap.put("E006", new Employee("E006","Kishan","Vijayanagar","9546563939",16000,16.34f));
		
		empMap.put("E005", new Employee("E005","Suman","Koramangala","9786393939",15000,15.34f));
		
	}
	public void fetchHashMapThruKeySet()
	{
		Set <String> myKeySet = empMap.keySet();
		Iterator <String> myKeyIter = myKeySet.iterator();
		while(myKeyIter.hasNext())
		{
			String myKey = myKeyIter.next();
			System.out.println("The Value for The Key "+myKey+" Is "+empMap.get(myKey));
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMapSample hms = new HashMapSample();
		hms.populateHashMap();
		hms.fetchHashMapThruKeySet();

	}

}
