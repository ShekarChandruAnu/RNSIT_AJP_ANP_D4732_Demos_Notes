package com.anu.rnsit;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

public class HashTableSample {

	Hashtable <String,Employee> empTable = new Hashtable<String,Employee>();
	public void manipulateHashTable()
	{
		/*
		 * Employee employee1 = new Employee("Harsha","RTNagar","9839393939",10000,12.34f);
		employees.add(employee1);
		employees.add(new Employee("Kiran","Vijayanagar","9865793939",12000,13.34f));
		employees.add(new Employee("Suman","Jayanagar","9865546939",12000,13.34f));
		employees.add(new Employee("Rajan","Malleswaram","9865657939",13000,14.34f));
		employees.add(new Employee("Vikas","Koramangala","9854693939",14000,15.34f));
		employees.add(new Employee("Manju","Vijayanagar","9865534939",13000,13.34f));
		employees.add(3, new Employee("Srujan","Jayanagar","9768534939",11000,13.34f));
		
		 */
		Employee employee1 = new Employee("E001","Harsha","RTNagar","9839393939",10000,12.34f);
		empTable.put("E001", employee1);
		
		empTable.put("E002", new Employee("E002","SreeHarsha","Vijayanagar","9544563939",12000,13.34f));
		empTable.put("E003", new Employee("E003","Sumanth","Jayanagar","9546393459",13000,12.34f));
		empTable.put("E004", new Employee("E004","Mahesh","Malleswaram","9546453939",14000,14.34f));
		empTable.put("E005", new Employee("E005","Suman","Koramangala","9786393939",15000,15.34f));
		empTable.put("E006", new Employee("E006","Kishan","Vijayanagar","9546563939",16000,16.34f));
		
		
	}
	public void fetchHashTableDataUsingKeys()
	{
		Enumeration <String> empEnumer = empTable.keys();
		while(empEnumer.hasMoreElements())
		{
			String empKey = empEnumer.nextElement();
			System.out.println("The value for the Key "+empKey+" Is "+empTable.get(empKey));
		}
		
	}
	public void fetchHashTableDataUsingValues()
	{
		Collection <Employee> myEmpCollection  = empTable.values();
		Iterator <Employee> myEmpIter= myEmpCollection.iterator();
		while(myEmpIter.hasNext())
		{
			System.out.println(myEmpIter.next());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashTableSample hts = new HashTableSample();
		hts.manipulateHashTable();
		System.out.println("-------Key & Values Dispalyed");
		hts.fetchHashTableDataUsingKeys();
		System.out.println("---- Values Dispalyed-----");
		hts.fetchHashTableDataUsingValues();

	}

}
