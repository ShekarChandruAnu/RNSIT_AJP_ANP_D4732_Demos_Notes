package com.anu.rnsit;


import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapSample {

	TreeMap <String,Employee> empTMap = new TreeMap<String,Employee>();
	public void populateTreeMap()
	{
		Employee employee1 = new Employee("E001","Harsha","RTNagar","9839393939",10000,12.34f);
		empTMap.put("E001", employee1);
		empTMap.put("E004", new Employee("E004","Mahesh","Malleswaram","9546453939",14000,14.34f));
		empTMap.put("E002", new Employee("E002","SreeHarsha","Vijayanagar","9544563939",12000,13.34f));
		empTMap.put("E003", new Employee("E003","Sumanth","Jayanagar","9546393459",13000,12.34f));
		empTMap.put("E006", new Employee("E006","Kishan","Vijayanagar","9546563939",16000,16.34f));
		empTMap.put("E005", new Employee("E005","Suman","Koramangala","9786393939",15000,15.34f));
		empTMap.put("E005", new Employee("E005a","Sumana","Vijayanagr","9786633939",15000,15.34f));
		
	}
	public void fetchTreeMapThruEntrySet()
	{
		Set <Entry <String,Employee>> myEntrySet = empTMap.entrySet();
		Iterator <Entry <String,Employee>> myEntryIter = myEntrySet.iterator();
		while(myEntryIter.hasNext())
		{
			Entry <String,Employee> myEntry = myEntryIter.next();
			System.out.println("The Key is "+myEntry.getKey()+" Corresponding Value is "+myEntry.getValue());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMapSample tms = new TreeMapSample();
		tms.populateTreeMap();
		tms.fetchTreeMapThruEntrySet();

	}

}
