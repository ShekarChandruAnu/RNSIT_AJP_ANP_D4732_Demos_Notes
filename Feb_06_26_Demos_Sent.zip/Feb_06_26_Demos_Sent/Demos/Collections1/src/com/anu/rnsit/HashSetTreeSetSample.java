package com.anu.rnsit;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetTreeSetSample {

	HashSet <String> hSet = new HashSet<String>();
	TreeSet <String> tSet = new TreeSet<String>();
	
	public void populateHashSet()
	{
		hSet.add("Fatehpur");
		hSet.add("Ernakulam");
		hSet.add("Coimbatore");
		hSet.add("Delhi");
		hSet.add("Bangalore");
		hSet.add("Ahmedabad");
	}

	public void populateTreeSet()
	{
		tSet.add("Fatehpur");
		tSet.add("Ernakulam");
		tSet.add("Coimbatore");
		tSet.add("Delhi");
		tSet.add("Bangalore");
		tSet.add("Ahmedabad");
	}
	public void fetchHashSet()
	{
		Iterator <String>  hSetIter = hSet.iterator();
		System.out.println("Hash Set Elements are....");
		while(hSetIter.hasNext())
		{
			System.out.println(hSetIter.next());
		}
	}
	public void fetchTreeSet()
	{
		Iterator <String> tSetIter = tSet.iterator();
		System.out.println("Tree Set Elements are...");
		while(tSetIter.hasNext())
		{
			System.out.println(tSetIter.next());
		}
				
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSetTreeSetSample hsts = new HashSetTreeSetSample();
		hsts.populateHashSet();
		hsts.fetchHashSet();
		System.out.println("------");
		hsts.populateTreeSet();
		hsts.fetchTreeSet();

	}

}
