package com.anu.rnsit;

public class Employee {
		
		String empName;
		String empAddress;
		String empPhone;
		int empSalary;
		float empTax;
		
		public Employee() {
			super();
		}

		public Employee(String empName, String empAddress, String empPhone, int empSalary, float empTax){
			super();
			this.empName = empName;
			this.empAddress = empAddress;
			this.empPhone = empPhone;
			this.empSalary = empSalary;
			this.empTax = empTax;
		}

		public String getEmpName() {
			return empName;
		}

		public void setEmpName(String empName) {
			this.empName = empName;
		}

		public String getEmpAddress() {
			return empAddress;
		}

		public void setEmpAddress(String empAddress) {
			this.empAddress = empAddress;
		}

		public String getEmpPhone() {
			return empPhone;
		}

		public void setEmpPhone(String empPhone) {
			this.empPhone = empPhone;
		}

		public int getEmpSalary() {
			return empSalary;
		}

		public void setEmpSalary(int empSalary) {
			this.empSalary = empSalary;
		}

		public float getEmpTax() {
			return empTax;
		}

		public void setEmpTax(float empTax) {
			this.empTax = empTax;
		}

		
		@Override
		public String toString() {
			return "Employee [empName=" + empName + ", empAddress=" + empAddress + ", empPhone=" + empPhone
					+ ", empSalary=" + empSalary + ", empTax=" + empTax + "]";
		}/**/
		
		
		
		
		
		
		
		
		

}
