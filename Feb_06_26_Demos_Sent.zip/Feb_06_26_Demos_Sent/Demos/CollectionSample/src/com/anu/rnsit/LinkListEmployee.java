package com.anu.rnsit;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkListEmployee {

	LinkedList <Employee> empployeesLL = new LinkedList<Employee>();
	
	public void manipulateLinkedList()
	{
		Employee employee1 = new Employee("Harsha","RTNagar","9839393939",10000,12.34f);
		empployeesLL.add(employee1);
		empployeesLL.add(new Employee("Kiran","Vijayanagar","9865793939",12000,13.34f));
		empployeesLL.add(new Employee("Suman","Jayanagar","9865546939",12000,13.34f));
		empployeesLL.add(new Employee("Rajan","Malleswaram","9865657939",13000,14.34f));
		empployeesLL.add(new Employee("Vikas","Koramangala","9854693939",14000,15.34f));
		empployeesLL.add(new Employee("Manju","Vijayanagar","9865534939",13000,13.34f));
		empployeesLL.addFirst(new Employee("Santhosh","Vijayanagar","9865464939",12500,13.34f));
		empployeesLL.addLast(new Employee("Melvin","Malleswaram","9865554639",13500,13.34f));
	}
	public void getLinkedListDataThruIter()
	{
		Iterator <Employee> empLLIter = empployeesLL.iterator();
		while(empLLIter.hasNext())
		{
			System.out.println(empLLIter.next());
		}
	}
	public void getRevLinkedListDataThruIter()
	{
		Iterator <Employee> empDescIter = empployeesLL.descendingIterator();
		while(empDescIter.hasNext())
		{
			System.out.println(empDescIter.next());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkListEmployee lle = new LinkListEmployee();
		lle.manipulateLinkedList();
		lle.getLinkedListDataThruIter();
		System.out.println("------");
		lle.getRevLinkedListDataThruIter();

	}

}
