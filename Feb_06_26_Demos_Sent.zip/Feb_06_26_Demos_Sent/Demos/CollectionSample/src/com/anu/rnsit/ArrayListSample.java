package com.anu.rnsit;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSample {
	
	ArrayList myList = new ArrayList();
	public void manipulateArrayList()
	{
		myList.add(2000);
		myList.add(234.56);
		myList.add("Hello World");
		myList.add(true);
		
	}
	public void fetchArrayList()
	{
		//Method 1
		System.out.println(myList);
		System.out.println("---------");
		//Method 2
		for(Object obj: myList)
		{
			System.out.println(obj);
		}
		System.out.println("----------");
		//Method 3
		Iterator myListIter = myList.iterator();
		while(myListIter.hasNext())
		{
			System.out.println(myListIter.next());
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListSample als = new ArrayListSample();
		als.manipulateArrayList();
		als.fetchArrayList();

	}

}
