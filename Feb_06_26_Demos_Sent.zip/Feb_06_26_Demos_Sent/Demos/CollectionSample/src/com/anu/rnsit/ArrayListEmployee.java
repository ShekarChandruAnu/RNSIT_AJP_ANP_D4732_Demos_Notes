package com.anu.rnsit;

import java.util.ArrayList;
import java.util.Iterator;


public class ArrayListEmployee {

	ArrayList <Employee> employees = new ArrayList<Employee>();
	//ArrayList myObjects = new ArrayList();
	public void manipulateArrayList()
	{
		Employee employee1 = new Employee("Harsha","RTNagar","9839393939",10000,12.34f);
		employees.add(employee1);
		employees.add(new Employee("Kiran","Vijayanagar","9865793939",12000,13.34f));
		employees.add(new Employee("Suman","Jayanagar","9865546939",12000,13.34f));
		employees.add(new Employee("Rajan","Malleswaram","9865657939",13000,14.34f));
		employees.add(new Employee("Vikas","Koramangala","9854693939",14000,15.34f));
		employees.add(new Employee("Manju","Vijayanagar","9865534939",13000,13.34f));
		employees.add(3, new Employee("Srujan","Jayanagar","9768534939",11000,13.34f));
		
	}
	public void getArrayListData()
	{
		System.out.println(employees);
		System.out.println("-------------");
		for(Employee x:employees)
		{
			System.out.println(x);
		}
		System.out.println("--------------");
		Iterator <Employee> empIter = employees.iterator();
		while(empIter.hasNext())
		{
			//Employee e = (Employee)empIter.next();
			Employee e = empIter.next();
			System.out.println(e);
		}
		System.out.println("Employee at Index 4 "+employees.get(4));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListEmployee ale = new ArrayListEmployee();
		ale.manipulateArrayList();
		ale.getArrayListData();

	}

}
