package com.fra.anu;

import java.util.Comparator;

public class SalarySorter implements Comparator <Employee>{

	@Override
	public int compare(Employee emp1, Employee emp2) {
		// TODO Auto-generated method stub
		if(emp1.employeeSalary > emp2.employeeSalary)
		{
			return 1;
		}
		else if(emp1.employeeSalary < emp2.employeeSalary)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	

}
