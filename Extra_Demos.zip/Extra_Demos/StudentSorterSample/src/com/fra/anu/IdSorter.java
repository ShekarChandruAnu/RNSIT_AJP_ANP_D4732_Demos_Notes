package com.fra.anu;

import java.util.Comparator;

public class IdSorter implements Comparator <Employee> {

	@Override
	public int compare(Employee emp1, Employee emp2) {
		// TODO Auto-generated method stub
		if(emp1.employeeId.compareTo(emp2.employeeId) > 0)
		{
			return 1;
		}
		else if(emp1.employeeId.compareTo(emp2.employeeId) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	

}
