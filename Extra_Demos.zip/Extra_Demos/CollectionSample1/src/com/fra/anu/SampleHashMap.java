package com.fra.anu;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class SampleHashMap {

	HashMap <String,Employee> employeeMap = new HashMap<String,Employee>();
	public void populateHashMap()
	{
		employeeMap.put("E004",new Employee("E004","Kiran Kumar","RTNagar","7383838393",1000,12.3f));
		employeeMap.put("E005",new Employee("E005","Kishan Kumar","Koramangala","7383865393",1200,11.3f));
		employeeMap.put("E006",new Employee("E006","Mohan Kumar","Jayanagar","7383838534",1500,14.3f));
		employeeMap.put("E003",new Employee("E003","Kiran Kumari","Vijayanagar","5463838393",1700,13.3f));
		employeeMap.put("E001",new Employee("E001","Meera Kumar","Malleswaram","7873838393",1200,11.3f));
		employeeMap.put("E002",new Employee("E002","Keerthana","Koramangala","7383834253",1300,10.3f));
		
	}
	public void fetchHashMap()
	{
		Set <Entry <String,Employee>> myEntrySet = employeeMap.entrySet();
		Iterator <Entry <String,Employee>> entryIter = myEntrySet.iterator();
		while(entryIter.hasNext())
		{
			Entry <String,Employee> myEntry = entryIter.next();
			System.out.println(" Key is "+myEntry.getKey()+" Value is "+myEntry.getValue());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SampleHashMap ss = new SampleHashMap();
		ss.populateHashMap();
		ss.fetchHashMap();

	}

}
