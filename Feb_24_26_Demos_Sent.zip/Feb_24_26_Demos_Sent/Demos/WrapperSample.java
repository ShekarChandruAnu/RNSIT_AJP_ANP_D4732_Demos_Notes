
public class WrapperSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x = 1000;
		Integer i = new Integer(x);
		System.out.println(" x as integer "+x);
		System.out.println(" i as Object "+i);
		System.out.println("------------------------");
		String iStr="10000";
		int iInt = Integer.parseInt(iStr);
		System.out.println(" iStr as String "+iStr);
		System.out.println(" iInt1  "+iInt);
		System.out.println("--------InCompatible conv-throws NUmberFormatException---------------");
		/*String iStr1="TenThousand";
		int iInt1 = Integer.parseInt(iStr1);
		System.out.println(" iStr1 as String "+iStr1);
		System.out.println(" iInt1  "+iInt1);*/
		System.out.println("------------------");
		String fStr="234.56";
		float flt1 = Float.parseFloat(fStr);
		System.out.println("The String converted to float "+flt1);
		System.out.println("------------------");
		String dStr = "34556.67";
		double dbl1 = Double.parseDouble(dStr);
		System.out.println("The String Converted to Double "+dbl1);
		
		Double db1 = new Double(2345.56);
		Double db2 = new Double("3455.67");
		System.out.println(" db1 used constructor with dbl "+db1);
		System.out.println(" db2  used constructor with dbl in string format "+db2);
		
		String dblStr = db1.toString();
		System.out.println("The Double converted to String "+dblStr);
		System.out.println("The Double converted to String calling toString"+db1);
		
		Float flt = new Float(234.56);
		String fltStr = flt.toString();
		System.out.println("flt converted to String :"+fltStr);

	}

}
