package com.anu.rnsit;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Students")
public class Student {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="studentId")
	int studentId;
	
	@Column(name="studentName")
	String studentName;
	
	@Column(name="studentAddress")
	String studentAddress;
	
	@Column(name="studentCourse")
	String studentCourse;
	
	@Column(name="studentEmail")
	String studentEmail;

	
	public Student() {
		super();
	}


	public Student(int studentId, String studentName, String studentAddress, String studentCourse,
			String studentEmail) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentAddress = studentAddress;
		this.studentCourse = studentCourse;
		this.studentEmail = studentEmail;
	}


	public Student(String studentName, String studentAddress, String studentCourse, String studentEmail) {
		super();
		this.studentName = studentName;
		this.studentAddress = studentAddress;
		this.studentCourse = studentCourse;
		this.studentEmail = studentEmail;
	}


	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public String getStudentName() {
		return studentName;
	}


	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}


	public String getStudentAddress() {
		return studentAddress;
	}


	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}


	public String getStudentCourse() {
		return studentCourse;
	}


	public void setStudentCourse(String studentCourse) {
		this.studentCourse = studentCourse;
	}


	public String getStudentEmail() {
		return studentEmail;
	}


	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}


	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentAddress=" + studentAddress
				+ ", studentCourse=" + studentCourse + ", studentEmail=" + studentEmail + "]";
	}
	
	
	
	

}
