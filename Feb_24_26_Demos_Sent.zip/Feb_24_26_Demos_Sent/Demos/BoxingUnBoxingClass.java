
public class BoxingUnBoxingClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object obj;
		int i =1000;
		//VALUE TYPE TO REFERENCE TYPE - IMPLICIT - BOXING 
		obj = i;
		System.out.println("The int converted to Object type "+obj);
		
		//REFERENCE TYPE TO VALUE TYPE -EXPLICIT - UNBOXING
		int x = (int)obj;
		System.out.println("The Obj cast to int is "+x);
		
		Object ox = "hello";
		
		//When UNBoxed - Compatibility needs to be there
		int y = (int)ox;
		//This may Throw Cast Exception
		System.out.println("The string Obj cast to int is "+y);
	}

}
