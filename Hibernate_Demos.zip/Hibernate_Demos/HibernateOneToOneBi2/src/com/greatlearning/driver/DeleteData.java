package com.greatlearning.driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.greatlearning.entity.Address;
import com.greatlearning.entity.Student;

public class DeleteData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// create session factory
				SessionFactory factory = new Configuration()
										.configure("hibernate.cfg.xml")
										.addAnnotatedClass(Student.class)
										.addAnnotatedClass(Address.class)
										.buildSessionFactory();

				// create session
				Session session = factory.getCurrentSession();

				try {

					int theAddressId=34;
					
					// start transaction
					session.beginTransaction();

					Address tempAddress = session.get(Address.class,theAddressId);
					
					if(tempAddress!=null) {
						System.out.println("Deleting : "+ tempAddress);
						
						//Note!! : it will also delete student data 
					    //         as we have provided CascadeType.ALL
						session.delete(tempAddress);
					}
					
					

					// commit transaction
					session.getTransaction().commit();

				} finally {
					factory.close();
				}

	}

}
