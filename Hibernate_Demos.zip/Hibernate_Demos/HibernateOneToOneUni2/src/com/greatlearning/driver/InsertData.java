package com.greatlearning.driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.greatlearning.entity.Address;
import com.greatlearning.entity.Student;




public class InsertData {

	public static void main(String[] args) {

		// create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml")
													.addAnnotatedClass(Student.class)
													.addAnnotatedClass(Address.class)
													.buildSessionFactory();
//Chained methods Java8 functionalprog
		// create session
		Session session = factory.getCurrentSession();
		try {
			// create the objects TRANSIENT
			Student tempStudent = new Student("Shravan Kumar", "Gupta", "shravan@greatlearning.com");

			Address tempAddress = new Address("Karnataka","Mangalore");
			// associate the objects
			tempStudent.setStudentAddress(tempAddress);
			// start transaction
			session.beginTransaction();

			// save the Student
			session.save(tempStudent); // PERSISTENT
					// commit transaction
			session.getTransaction().commit();

		} finally {
			factory.close();
		}
	}
}
