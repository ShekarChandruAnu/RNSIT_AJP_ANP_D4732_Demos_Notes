
package com.greatlearning.driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.greatlearning.entity.Course;
import com.greatlearning.entity.Review;
import com.greatlearning.entity.Teacher;
import com.greatlearning.entity.TeacherDetails;
public class InsertCourseAndReview {

	public static void main(String[] args) {

		// create session factory
		SessionFactory factory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class)
				.addAnnotatedClass(Course.class)
				.addAnnotatedClass(Review.class)
				.buildSessionFactory();

		// create session
		Session session = factory.getCurrentSession();

		try {

			//start a transaction
			session.beginTransaction();

			// create the objects
			Course tempCourse = new Course("Thymeleaf");
			int x=6;
			Teacher tempTeacher =session.get(Teacher.class, x);

			//add some review
			tempCourse.addReview(new Review("Good UI Course"));
			tempCourse.addReview(new Review(" Really loved it"));
			tempCourse.addReview(new Review("Awesome UI Course"));
			tempCourse.addReview(new Review("Something Valuable"));
			/*
			 * Get Teacher whose id is 6
			 * Create New Course
			 * add reviews to the course - through convenience method
			 * add course to the teacher - through convenience method
			 * save course
			 */
			
			tempTeacher.add(tempCourse);
			//save course and leverage the cascade all
			System.out.println("Saving Course");
			System.out.println(tempCourse);
			System.out.println(tempCourse.getReviews());
			session.save(tempCourse);

			//commit transaction
			session.getTransaction().commit();

			System.out.println("Done");

		} finally {
			//add a clean up code
			session.close();

			factory.close();
		}
	}
}


