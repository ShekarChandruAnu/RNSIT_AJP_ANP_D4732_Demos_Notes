package com.anu.rns1;

public class Point {
	
	int xCoord;
	int yCoord;
	
	public Point()
	{
		
	}
	public Point(int xCoord,int yCoord)
	{
		
	}
	public void displayPoint()
	{
		System.out.println("X Coordinate is "+xCoord+"  ANd Y Coordinate is "+yCoord);
	}

}
