package com.anu.rns;

public class Employee {
	
	String empName;
	String empAddress;
	String empPhone;
	
	
	
	public Employee() {
		super();
	}
	
	
	public Employee(String empName, String empAddress, String empPhone) {
		super();
		this.empName = empName;
		this.empAddress = empAddress;
		this.empPhone = empPhone;
	}
	

	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public String getEmpAddress() {
		return empAddress;
	}


	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}


	public String getEmpPhone() {
		return empPhone;
	}


	public void setEmpPhone(String empPhone) {
		this.empPhone = empPhone;
	}


	//PAREMETERLESS CONSTRUCTOR - DEFAULT CONSTRUCTOR
	 /* public Employee()
	{
		super();
		empName = "Harsha";
		empAddress = "RTNagar";
		empPhone = "8929299292";
	}
	 public Employee(String empName,String empAddress,String empPhone)
	{
		// Employee ex = new Employee();
		this.empName = empName;
		this.empAddress = empAddress;
		this.empPhone = empPhone;
	}/**/
/*	public void setEmpName(String empName)
	{
		this.empName = empName;
	}
	public String getEmpName()
	{
		return this.empName;
	}
	public void setEmpAddress(String empAddress)
	{
		this.empAddress = empAddress;
	}
	public String getEmpAddress()
	{
		return this.empAddress;
	}*/
	public void display()
	{
		System.out.println("Displaying thru Display Method");
		System.out.println("Employee Name "+empName);
		System.out.println("Employee Address "+empAddress);
		System.out.println("Employee Phone "+empPhone);
	}
	public String toString()
	{
		return "Employee "+empName+" Residing at "+empAddress+" has a contact No"+empPhone;
	}
	public static void main(String[] args)
	{
		//System.out.println("welcome to Java Programming");
		Employee e1 = new Employee();
		e1.display();
		System.out.println(e1);
		
	/*	Employee e2 = new Employee("Kiran","Jayanagar","8939399334");
		e2.display();
		
		e2.setEmpName("Rajendra");
		e2.setEmpAddress("Koramangala");
		e2.display();
		System.out.println("the Emp Name "+e2.getEmpName());*/
	}

}
