package com.anu.rns1;

public class PointManipulator {

	public Point[] generatePointArray()
	{
		Point points[] = new Point[10];
		
		
		
		
		return points;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
