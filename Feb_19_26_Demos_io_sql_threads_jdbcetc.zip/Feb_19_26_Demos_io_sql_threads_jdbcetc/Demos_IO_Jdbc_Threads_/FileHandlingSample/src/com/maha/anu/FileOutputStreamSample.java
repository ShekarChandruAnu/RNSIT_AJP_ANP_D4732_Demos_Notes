package com.maha.anu;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamSample {

	// ctrl+shift+O  this is not zero o for Orissa
	FileOutputStream fos;
	byte[] mybytes = new byte[100];
	String str = "we are writing data into a file through Binary Stream";
	public void writeToBinaryStream()
	{
		try {
			fos = new FileOutputStream("customer.txt");
			mybytes = str.getBytes();
			fos.write(mybytes);
			fos.flush();
			fos.close();
			System.out.println("We have written into a File through Binary STream Successfully...");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileOutputStreamSample foss = new FileOutputStreamSample();
		foss.writeToBinaryStream();
	}

}
