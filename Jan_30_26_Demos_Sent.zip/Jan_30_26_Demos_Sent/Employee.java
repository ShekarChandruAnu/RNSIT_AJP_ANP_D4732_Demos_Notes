public class Employee
{
	public static void main(String[] args)
	{
		for(int i=0;i<args.length;i++)
		{
			System.out.println("The Element is "+args[i]);
		}
	}


}