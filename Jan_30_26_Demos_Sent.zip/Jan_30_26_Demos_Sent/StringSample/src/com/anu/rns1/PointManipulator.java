package com.anu.rns1;

public class PointManipulator {

	public Point[] generatePointArray()
	{
		Point points[] = new Point[10];
		/*points[0]= new Point();
		 * points[1] = new Point();
		 * */
		for(int i=0;i<10;i++)
		{
			points[i] = new Point(i+10,i+20);
		}
		 return points;	
	}
	public int add()
	{
		int x = 100;
		//
		return x;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PointManipulator pointer = new PointManipulator();
		Point[] myPoints = pointer.generatePointArray();
	//	int result = pointer.add();
		//myPoints[0].disp
		for(int i=0;i<10;i++)
		{
			myPoints[i].displayPoint();
		}

	}

}
