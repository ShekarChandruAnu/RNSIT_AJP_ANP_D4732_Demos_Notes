package com.anu.rns1;

public class ArrayAddition {

	public int[][] addArray(int[][] arr1,int[][] arr2)
	{
		int[][] resultArray = new int[2][3];
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<3;j++)
			{
				resultArray[i][j]=arr1[i][j]+arr2[i][j];
			}
		}
		return resultArray;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x =args.length;
		int myResultArray[][] = new int[2][3];
		int myArray1[][] = {{10,20,30},{100,200,300}};
		int myArray2[][] = {{100,200,300},{1000,2000,3000}};
		ArrayAddition aadd = new ArrayAddition();
		myResultArray = aadd.addArray(myArray1, myArray2);

	}

}
