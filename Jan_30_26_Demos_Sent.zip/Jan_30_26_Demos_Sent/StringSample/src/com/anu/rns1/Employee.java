package com.anu.rns1;

public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<args.length;i++)
		{
			System.out.println("City is "+args[i]);
		}

	}

}
