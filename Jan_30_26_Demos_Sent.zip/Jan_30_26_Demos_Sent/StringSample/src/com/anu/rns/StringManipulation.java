package com.anu.rns;

import java.util.StringTokenizer;

public class StringManipulation {

	public void manipulateString()
	{
		String str1 = "Bangalore";
		String str2 = "bangalore";
		str2 = "Chennai";// str2 point to new reference
		// Bangalore is pointed by str1 if not Garbage collected
				
		// equals ==
		// equals method compares the values held by the objects
		// == operator compares the references
		System.out.println("str1.equals(str2) :"+str1.equals(str2));// true
		System.out.println("str1 == str2 :"+(str1 == str2));//true
		
		String str3 = new String("Hyderabad");
		String str4 = new String("Hyderabad");
	
		
		System.out.println("str3.equals(str4) :"+str3.equals(str4));// true
		System.out.println("str3 == str4 :"+(str3 == str4));//false
		
		System.out.println(" str1.charAt(4) :"+str1.charAt(4) );
		System.out.println("str1.codePointAt(4) :"+str1.codePointAt(4));
		System.out.println(" str1.length() :"+str1.length());
		System.out.println( " str1.compareTo(str2) "+str1.compareTo(str2));
		System.out.println(" str1.concat(str2) :"+str1.concat(str2));
		System.out.println(" str1.indexOf(4) "+str1.indexOf(4));
	}
	public void manipulateStringBuilderBuffer()
	{
		//STRINGBUILDER IS MUTABLE & NOT SYNCRHONIZED
		StringBuilder sbr1 = new StringBuilder("India is Incredible ");
		
		char[] chars = {'A','n','d',' ','P','e','a','c','e','f','u','l'};
		sbr1.insert(19, chars);
		System.out.println(sbr1);
		System.out.println(sbr1.append(" and Rich in Culture"));
		System.out.println("sbr 1 after appending & inserting "+sbr1);
		System.out.println("--------------------");
		//STRINGBUFFER IS MUTABLE AND SYNCHRONIZED
		StringBuffer sbfr1 = new StringBuffer("India is Incredible ");
		char[] chars1 = {'A','n','d',' ','P','e','a','c','e','f','u','l'};
		sbfr1.insert(19, chars1);
		System.out.println(sbfr1);
		System.out.println(sbfr1.append(" and Rich in Culture"));
		System.out.println("sbfr 1 after appending & inserting "+sbfr1);
		
	}
	public void manipulateStringTokenizer()
	{ // ctrl+shift+o
		StringTokenizer strTokens = new StringTokenizer("india:is:great:and:peaceful",":");
		System.out.println("Using Has More Elements : The Elements are ");
		while(strTokens.hasMoreElements())
		{
			System.out.println(strTokens.nextElement());
		}
		System.out.println("-------------");
		StringTokenizer strTokens1 = new StringTokenizer("india:is:great:and:peaceful",":");
		System.out.println("Using Has More Tokens : The Tokens are ");
		while(strTokens1.hasMoreTokens())
		{
			System.out.println(strTokens1.nextToken());
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringManipulation strManip = new StringManipulation();
		//strManip.manipulateString();
		//strManip.manipulateStringBuilderBuffer();
		strManip.manipulateStringTokenizer();

	}

}
