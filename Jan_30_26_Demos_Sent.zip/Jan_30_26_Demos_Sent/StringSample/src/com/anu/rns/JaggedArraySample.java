package com.anu.rns;

public class JaggedArraySample {

	public void manipulateJaggedArray()
	{
		int jagArr[][] = new int[4][];
		jagArr[0]= new int[4];//0th Row consists 4 columns
		jagArr[1] = new int[3];
		jagArr[2] = new int[6];
		jagArr[3] = new int[5];
		
		for(int i=0;i<4;i++)
		{
			jagArr[0][i] = (i+1)*10;
			System.out.print(jagArr[0][i]+" ");
		}
		System.out.println("------");
		for(int j=0;j<3;j++)
		{
			jagArr[1][j] = (j+1)*100;
			System.out.print(jagArr[1][j]+" ");
		}
		System.out.println("------");
		for(int k=0;k<6;k++)
		{
			jagArr[2][k] = (k+1)*1000;
			System.out.print(jagArr[2][k]+" ");
		}
		System.out.println("------");
		for(int l=0;l<5;l++)
		{
			jagArr[3][l] = (l+1)*10000;
			System.out.print(jagArr[3][l]+" ");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JaggedArraySample jars = new JaggedArraySample();
		jars.manipulateJaggedArray();

	}

}
