package com.anu.rns2;

public class SoftwareEngineer {

	public void getData(int score1,int score2,String... cities)
	{
		int totalScore = score1+score2;
		System.out.println("The Cities where score is totalled");
		for(int i=0;i<cities.length;i++)
		{
			System.out.println("The City is "+cities[i]);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SoftwareEngineer se = new SoftwareEngineer();
		se.getData(75, 85, "Hyderabad","Chennai","Bangalore");
		System.out.println("-----");
		se.getData(65, 95, "Hyderabad","Chennai","Bangalore","Mumbai");
		System.out.println("-----");
		se.getData(95, 65, "Hyderabad","Chennai","Bangalore","Delhi","Nagpur");

	}

}
