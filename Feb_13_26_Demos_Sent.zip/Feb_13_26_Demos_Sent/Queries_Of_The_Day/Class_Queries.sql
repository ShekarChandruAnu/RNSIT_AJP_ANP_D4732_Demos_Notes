create Database RNSIT;
use RNSIT;

create table Employee
(
empId varchar(20) primary key ,
empName varchar(50),
empAddress varchar(100),
empPhone varchar(50),
empSalary int,
empDOJ date
);
select * from Employee;

create table NewEmployee
as
select * from Employee ;

select * from NewEmployee;

update newEmployee
set employeeAddress = 'Jayanagar',
employeeSalary = 20000 where employeeId = 'E001';
select * from employee;
delete from NewEmployee where employeeId = 'E002';
-- vs
delete from NewEmployee;
select * from NewEmployee;

insert into NewEmployee
values
('E001','Harshitha','Koramangala','9839393993',20000,'2024-12-23',12.34);
select * from NewEmployee;

describe NewEmployee;

select * from Employee;
create table NewEmployee1
as
select * from Employee;

select * from NewEmployee1;

use rnsit;

select * from Employee;

create table NewEmployee
as
select * from Employee;




select * from NewEmployee;

insert into NewEmployee
values
('E001','Kiran Kumar','Malleswaram','8939939393',25000,'2023-06-21');

select * from NewEmployee;

delete from NewEmployee;
select * from NewEmployee;
drop table NewEmployee;
use rnsit;

truncate table NewEmployee;
-- GROUP BY
create table Movies
(
MovieId varchar(20) primary key,
MovieCategory varchar(30),
MovieName varchar(20),
Collections int);

drop table Movies;
insert into Movies
values
('M1','Comedy','HAHK',450000),
('M2','Tragedy','HSKK',550000),
('M3','Drama','JHGK',650000),
('M4','Comedy','STRA',750000),
('M5','Drama','LKAP',850000),
('M6','Comedy','WRTS',950000),
('M7','Drama','NJFMSD',350000),
('M8','Tragedy','SKJD',850000),
('M9','Comedy','KJHA',1250000),
('M10','Tragedy','SIYT',1150000),
('M11','Action','OUAY',750000),
('M12','Tragedy','LKAP',900000),
('M13','Action','SMNX',1100000);
select * from Movies;

select MovieCategory,
avg(Collections) as 'Average Collections',
max(Collections) as 'Maximum Collections',
min(Collections) as 'Minimum Collections',
sum(Collections) as 'Total Collections'
from Movies
group by MovieCategory;

select MovieCategory,
avg(Collections) as 'Average Collections',
max(Collections) as 'Maximum Collections',
min(Collections) as 'Minimum Collections',
sum(Collections) as 'Total Collections'
from Movies
group by MovieCategory having avg(Collections) > 850000;

/*
select concat('hello','world','new');

select concat(sFirstName,sLastName) as 'Supplier FullName' from Supplier;

select insert("Internet",4,3,'mission');

select instr('Internet','net');

select field('three','two','three','two','four','four');

select reverse('hello');

select ltrim('      hello');

select substring('hello world',3,6);

select replace('hello world','o','p');

select left('world over',4);

select right('world over',4);

select space(5);

*/
select concat('hello','world','new');

create table Student
(
studId varchar(20),
firstName varchar(50),
lastName varchar(50),
Course varchar(50)
);

insert into Student
values
('S001','Rajan','Gupta','MCA'),
('S002','Kiran','Sharma','BCA'),
('S003','Rajat','Khurana','BTech'),
('S004','Rajan','Verma','MCA'),
('S005','Rajesh','Sinha','BTech');
select * from Student;

select concat(firstName,' ',lastName) as 'Full Name',course from Student;

select concat(firstName,space(2),lastName) as 'Full Name',course from Student;
select insert("Internet",4,3,'mission');
select substring('hello world',3,6);
select substring(firstName,1,1) as 'Initials',lastName , course from Student;

select concat(substring(firstName,1,1) ,'.',lastName) as 'FullName' , course from Student;

select concat(upper(substring(firstName,1,1)) ,'.',lastName) as 'FullName' , course from Student;

select ltrim('      hello');

select reverse('hello');
select instr('Internet','net');
select left('world over',4);
select right('world over',4);
select field('three','two','three','two','four','four');
select field('four','two','three','two','four','four');
select upper('hello');


select strcmp('harsha','harshit');

select ascii('h');

select upper(sFirstname) from supplier;
-- MATH FUNCTIONS
select ceil(2.3456);
select floor(2.3456);
select log10(100);
select mod(245,10);

select 245 mod 10;
select radians(90);
select round(degrees(1.57));
select round(sin(1.57));
select pow(2,3);
select sqrt(144);
--    DATE FUNCTIONS
# Currrent Date
select curdate();
# Current Date & Time
select now();
#Current Time only
select curtime();
select * from Employee;

select empName,
empDOJ as 'Date Of Joining' , 
datediff(curdate(),empDOJ) as 'NoOfDays Since Joined'  
from employee;

select empName,
empDOJ as 'Date Of Joining' , 
datediff(curdate(),empDOJ) as 'NoOfDays Since Joined'  ,
datediff(curDate(),empDOJ)/365 as 'No of Years Since Joined',
datediff(curDate(),empDOJ)/365 * 12 as 'No of Months Since Joined'
from employee;

select date_add(curdate(),interval 2 year);
select date_add(curdate(),interval 2 day);

select date_add(curdate(),interval 2  QUARTER);

select date_sub(curdate(),interval 25 day);

select date_sub(curdate(),interval 2 YEAR);

-- PRIMARY KEY WHILE CREATING TABLE

create table Students
(
studentId varchar(20) primary key,
studentName varchar(50),
studentAddress varchar(50),
studentCourse varchar(50)
);
-- PRIMARY KEY WHILE CREATING TABLE but after specifying column
create table Students1
(
studentId varchar(20),
studentName varchar(50),
studentAddress varchar(50),
studentCourse varchar(50),
constraint cpKey1 primary key(studentId)
);
describe Students1;
insert into Students1
values('S001','Keerthana','RTNagar','MCA');

create table Students2
(
studentId varchar(20),
studentName varchar(50),
studentAddress varchar(50),
studentCourse varchar(50)
);

insert into Students2
values
('S001','Keerthana','RTNagar','MCA'),
('S001','Sumanth','RTNagar','MCA');

select * from Students2;

update  Students2
set studentId = 'S002' where studentName = 'Sumanth';

alter table Students2
add constraint priKey1 primary key(studentId);
drop table agent;
-- POSSIBILITY
create table agent
(
agentId varchar(20) primary key,
agencyName varchar(40),
agencyContact varchar(30) default 'No PHONE',
agencyMail varchar(50),
constraint cunique1 unique (agencyMail),
constraint chk100 check (agencyMail like '%@%.com')
);
-- harshit@gmail.com
insert into agent
values('A001','RK Traders','9829292992','rktrad@gmail.com');
select * from agent;

insert into agent(agentId,agencyName,agencyMail)
values('A008','RSK Traders','rsktrad@gmail.com');
-- DROP COLUMN and adding
/*
alter table agent
drop column agencyContact;

alter table agent
add column agencyContact varchar(40) null;*/

alter table agent
modify agencyContact varchar(40) null;

alter table agent
drop check chk100;

alter table agent
drop index cunique1;

alter table agent
alter agencyContact drop default;

-- adding unique and default after creating the table
create table agency
(
agencyCode varchar(30) primary key,
agencyName varchar(50),
agencyContact varchar(50),
agencyMail varchar(75)
);
alter table agency
alter agencyContact set default 'No PHONE';
select * from agency;

alter table agency
add constraint cunique2 unique(agencyMail);

alter table agency
drop index cunique2;

insert into agency
values('A003','MK Traders','9829292992','sk@gmail.com');
----- JOINS
/*
create table Customers1
(
CustomerId varchar(10) primary key,
CustomerName varchar(30),
CustomerAddress varchar(30)
);
insert into Customers1
values
('C0001','Kishore','RTNagar'),
('C0002','Kiran','RRNagar'),
('C0003','Kumar','IndiraNagar'),
('C0004','mahesh','JayaNagar');
create table Suppliers1
(
SupplierId varchar(20) primary key,
SupplierRegion varchar(30),
SupplierContact varchar(20)
);
insert into Suppliers1
values
('S0001','South','9828828882'),
('S0002','North','9825369882'),
('S0003','West','9825428882');

create table Products1
(
ProductId varchar(20) primary key,
ProductName varchar(20) ,
ProdCategory varchar(20),
SupplierId varchar(20),
constraint csupfkey foreign key (SupplierId) references Suppliers1(SupplierId)
);
insert into Products1
values
('P001','Television','Electronics','S0001'),
('P002','Refrigerator','HomeAppliance','S0001'),
('P003','AudioPlayer','Electronics','S0002'),
('P004','WashingMachine','HomeAppliance','S0003'),
('P005','VacuumCleaner','Electronics','S0001'),
('P006','MixerGrinder','HomeAppliance','S0002');

create table Orders1
(
OrderId varchar(20) primary key,
OrderDate date,
ProductId varchar(20),
Quantity int,
OrderValue float,
CustomerId varchar(20),
constraint cprodfkey foreign key (ProductId) references Products1(ProductId),
constraint ccustfkey foreign key (CustomerId) references Customers1(CustomerId)
);
insert into Orders1
values
('O001','2020-02-20','P001',10,50000,'C0001'),
('O002','2019-04-22','P002',20,150000,'C0001'),
('O003','2020-05-25','P001',15,175000,'C0002'),
('O004','2019-03-21','P003',12,70000,'C0003'),
('O005','2019-02-12','P004',11,60000,'C0004'),
('O006','2020-01-13','P004',5,25000,'C0001'),
('O007','2020-08-22','P005',9,80000,'C0002');

select * from Customers1;
select * from Products1;
select * from Suppliers1;
select * from Orders1;

*/
create table Customers1
(
CustomerId varchar(10) primary key,
CustomerName varchar(30),
CustomerAddress varchar(30)
);

insert into Customers1
values
('C0001','Kishore','RTNagar'),
('C0002','Kiran','RRNagar'),
('C0003','Kumar','IndiraNagar'),
('C0004','mahesh','JayaNagar');

insert into Customers1
values
('C0005','Rajesh','RTNagar'),
('C0006','Srinath','KRPuram');

create table Suppliers1
(
SupplierId varchar(20) primary key,
SupplierRegion varchar(30),
SupplierContact varchar(20)
);
insert into Suppliers1
values
('S0001','South','9828828882'),
('S0002','North','9825369882'),
('S0003','West','9825428882');


create table Products1
(
ProductId varchar(20) primary key,
ProductName varchar(20) ,
ProdCategory varchar(20),
SupplierId varchar(20),
constraint csupfkey foreign key (SupplierId) references Suppliers1(SupplierId)
);
insert into Products1
values
('P001','Television','Electronics','S0001'),
('P002','Refrigerator','HomeAppliance','S0001'),
('P003','AudioPlayer','Electronics','S0002'),
('P004','WashingMachine','HomeAppliance','S0003'),
('P005','VacuumCleaner','Electronics','S0001'),
('P006','MixerGrinder','HomeAppliance','S0002');
create table Orders1
(
OrderId varchar(20) primary key,
OrderDate date,
ProductId varchar(20),
Quantity int,
OrderValue float,
CustomerId varchar(20),
constraint cprodfkey foreign key (ProductId) references Products1(ProductId),
constraint ccustfkey foreign key (CustomerId) references Customers1(CustomerId)
);
insert into Orders1
values
('O001','2020-02-20','P001',10,50000,'C0001'),
('O002','2019-04-22','P002',20,150000,'C0001'),
('O003','2020-05-25','P001',15,175000,'C0002'),
('O004','2019-03-21','P003',12,70000,'C0003'),
('O005','2019-02-12','P004',11,60000,'C0004'),
('O006','2020-01-13','P004',5,25000,'C0001'),
('O007','2020-08-22','P005',9,80000,'C0002');

select * from Customers1;
select * from Products1;
select * from Suppliers1;
select * from Orders1;

select Customers1.customerId,CustomerName,CustomerAddress,
OrderDate,Quantity,OrderValue,ProductName,ProdCategory,
SupplierRegion,SupplierContact
from Customers1 join Orders1
on Customers1.customerId = Orders1.customerId
join Products1
on Orders1.productId = Products1.ProductId
join Suppliers1
on Products1.supplierId = Suppliers1.supplierId;


select c.customerId,CustomerName,CustomerAddress,
OrderDate,Quantity,OrderValue,ProductName,ProdCategory,
SupplierRegion,SupplierContact
from Customers1 c join Orders1 o
on Customers1.customerId = Orders1.customerId
join Products1 p
on Orders1.productId = Products1.ProductId
join Suppliers1
on Products1.supplierId = Suppliers1.supplierId;



-----------------------------------------------------
#INNER JOINS  [equi join]
select * from  Customers1 inner join Orders1 
on Customers1.CustomerId = Orders1.CustomerId; 
--  [ Non equi join]
select * from  Customers1 inner join Orders1 
on Customers1.CustomerId < Orders1.CustomerId;

-----------------------------------------# LEFT OUTER JOIN
select Customers1.customerId,CustomerName,CustomerAddress,OrderDate,OrderValue
from Customers1 left outer join Orders1
on Customers1.CustomerId = Orders1.CustomerId;

-------------------------------------# RIGHT OUTER JOIN
select Customers1.customerId,CustomerName,CustomerAddress,OrderDate,OrderValue
from Customers1 right outer join Orders1
on Customers1.CustomerId = Orders1.CustomerId;

-----------------------------------#CROSS JOIN
select customers1.*,Orders1.* from
Customers1 cross join Orders1;

select customers1.*,orders1.*
from customers1 cross join orders1;
------------------------------------# NATURAL Join
select * from  Customers1 natural join Orders1 ;

# --------------------------FULL JOIN-------------
select * from customers1 full join orders1;
-- ---------------------------------------SELF JOIN--------------------------

create table Authors
(
AuthorId varchar(20) primary key,
AuthorName varchar(40),
AuthorCity varchar(40)
);
insert into Authors
values
# A									B
('A001','Kuvempu','Mysore'),		('A001','Kuvempu','Mysore'),
('A002','Akilan','Chennai'),		('A002','Akilan','Chennai'),
('A003','Shakespeare','London'),	('A003','Shakespeare','London'),
('A004','Shelly','London'),		('A004','Shelly','London'),	
('A005','Hari','Allahabad'),		('A005','Hari','Allahabad'),	
('A006','AnaKru','Mysore'),		('A006','AnaKru','Mysore'),
('A007','Nisar','Bangalore'),		('A007','Nisar','Bangalore'),
('A008','Keats','London'),		('A008','Keats','London'),
('A009','Wordsworth','London');	('A009','Wordsworth','London');


select a.authorId,a.authorName,a.authorCity,b.authorId,b.authorName,b.authorCity
from Authors a join Authors b
on a.authorCity = b.authorCity
and
a.authorId < b.authorId;

insert into Authors
values
('A001','Kuvempu','Mysore'),	
('A002','Akilan','Chennai'),		
('A003','Shakespeare','London'),	
('A004','Shelly','London'),		
('A005','Hari','Allahabad'),		
('A006','AnaKru','Mysore'),		
('A007','Nisar','Bangalore'),		
('A008','Keats','London'),		
('A009','Wordsworth','London');	

select * from Employee;


create table StudentInfo
(
StudentId varchar(20) primary key,
StudentName varchar(30),
StudentState varchar(30),
StudentCity varchar(30)
);
/*
Andhra Assam Goa Karnataka Kerala Madhyapradesh Maharashtra TamilNadu
Amarendra	 Bhupendra Chandan Christie David Dravid Faheem Farhan Ganesh Emanuel Yasmeen
Zeenat
*/
insert into StudentInfo
values
('S001','KiranKumar', 'Andhra' ,'Vijayawada'),
('S002','Amarendra', 'Andhra' ,'Vizag'),
('S003','Christie', 'Andhra' ,'Hyderabd'),
('S004','Chandan', 'Andhra' ,'Anantpur'),
('S005','Emanuel', 'Assam' ,'Gauhati'),
('S006','Ganesh', 'Karnataka' ,'Bangalore'),
('S007','Greeshma', 'Maharashtra' ,'Mumbai'),
('S008','Harsha', 'Assam' ,'Dispur'),
('S009','Yasmeen', 'Karnataka' ,'Mysore'),
('S010','Zeenat', 'Maharashtra' ,'Pune'),
('S011','Dhruva', 'Assam' ,'Cherrapunji'),
('S012','Dominic', 'Karnataka' ,'Mangalore'),
('S013','Catherine', 'TamilNadu' ,'Chennai'),
('S014','Amar', 'TamilNadu' ,'Coimbatore'),
('S015','Dharmesh', 'Goa' ,'Panaji'),
('S016','GuruKiran', 'TamilNadu' ,'Madurai');
select * from StudentInfo;

select studentId from StudentInfo;
select studentName from studentInfo;
select StudentName from studNameIdx;


select studentId,StudentCity from StudentInfo;

create index studNameIdx
on StudentInfo(StudentName);

select studentCity from StudentInfo;

create index cityStateIdx
on StudentInfo(StudentState,StudentCity);
select StudentState,StudentCity from studentInfo;

alter table StudentInfo
drop index cityStateIdx;

